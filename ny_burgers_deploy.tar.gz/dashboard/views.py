import secrets as _secrets
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404
from django.views.decorators.http import require_POST
from django.http import JsonResponse, HttpResponse
from django.contrib import messages
from django.db import transaction
from decimal import Decimal, InvalidOperation

from django.utils import timezone
from django.db.models import Count, Max, Sum, Q
from datetime import timedelta
from core.models import Restaurant, Branch, Membership, PromoCode, PageView
from catalog.models import (
    BranchItem, BranchCategory, BranchCategoryItem,
    Item, ItemCategory, Category, MenuSet, BranchMenuSet,
    DishConstructor, ConstructorGroup, ConstructorIngredient,
)
from catalog.services import ensure_links_for_branch_item
from reservations.models import Floor, Place


def _int_or_none(raw):
    raw = (raw or "").strip()
    return int(raw) if raw.isdigit() else None


def _decimal_or_none(raw):
    raw = (raw or "").strip().replace(",", ".")
    if not raw:
        return None
    try:
        return Decimal(raw)
    except InvalidOperation:
        return None


def _user_restaurants(user):
    ids = Membership.objects.filter(user=user).values_list("restaurant_id", flat=True)
    return Restaurant.objects.filter(id__in=ids)


def _has_branch_access(user, branch):
    return Membership.objects.filter(user=user, restaurant=branch.restaurant).exists()


# ── AUTH ─────────────────────────────────────────────────────────────────────

def login_view(request):
    if request.user.is_authenticated:
        return redirect("dashboard:home")

    if request.method == "POST":
        user = authenticate(
            request,
            username=request.POST.get("username", "").strip(),
            password=request.POST.get("password", ""),
        )
        if user:
            login(request, user)
            return redirect("dashboard:home")
        messages.error(request, "Неверный логин или пароль")

    return render(request, "dashboard/login.html")


def logout_view(request):
    logout(request)
    return redirect("dashboard:login")


@login_required(login_url="dashboard:login")
def profile_view(request):
    from core.models import UserProfile
    profile, _ = UserProfile.objects.get_or_create(
        user=request.user,
        defaults={"phone": ""},
    )
    error = None
    success = False
    if request.method == "POST":
        phone = request.POST.get("phone", "").strip()
        if not phone.startswith("+996") or len(phone) < 10:
            error = "Введите номер в формате +996XXXXXXXXX (минимум 10 символов)"
        else:
            profile.phone = phone
            profile.save(update_fields=["phone"])
            success = True
    return render(request, "dashboard/profile.html", {
        "profile": profile,
        "error": error,
        "success": success,
    })


# ── HOME ─────────────────────────────────────────────────────────────────────

@login_required(login_url="dashboard:login")
def home(request):
    from orders.models import Order

    restaurants = _user_restaurants(request.user).prefetch_related("branches")

    now = timezone.now()
    today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    week_start  = today_start - timedelta(days=today_start.weekday())
    month_start = today_start.replace(day=1)

    data = []
    for r in restaurants:
        branches = list(r.branches.filter(is_active=True).order_by("name_ru"))
        branch_ids = [b.id for b in branches]

        def _sum(qs):
            return qs.aggregate(s=Sum("total_amount"))["s"] or 0

        base = Order.objects.filter(branch_id__in=branch_ids).exclude(status=Order.Status.CANCELLED)
        rev = {
            "today":  _sum(base.filter(created_at__gte=today_start)),
            "week":   _sum(base.filter(created_at__gte=week_start)),
            "month":  _sum(base.filter(created_at__gte=month_start)),
            "today_cnt":  base.filter(created_at__gte=today_start).count(),
            "week_cnt":   base.filter(created_at__gte=week_start).count(),
            "month_cnt":  base.filter(created_at__gte=month_start).count(),
        }
        data.append({"restaurant": r, "branches": branches, "rev": rev})

    from karaoke.models import KaraokeVenue, KaraokeMembership
    user = request.user
    if user.is_staff or user.is_superuser:
        karaoke_venues = list(KaraokeVenue.objects.prefetch_related("rooms").all())
    else:
        ids = KaraokeMembership.objects.filter(user=user).values_list("venue_id", flat=True)
        karaoke_venues = list(KaraokeVenue.objects.filter(id__in=ids).prefetch_related("rooms"))

    return render(request, "dashboard/home.html", {"data": data, "karaoke_venues": karaoke_venues})


# ── RESTAURANT ───────────────────────────────────────────────────────────────

@require_POST
@login_required(login_url="dashboard:login")
def restaurant_create(request):
    if not request.user.is_superuser:
        messages.error(request, "Недостаточно прав для создания ресторана.")
        return redirect("dashboard:home")

    from django.utils.text import slugify
    import uuid
    from catalog.models import MenuSet, BranchMenuSet

    name = request.POST.get("name_ru", "").strip()
    if not name:
        messages.error(request, "Введите название")
        return redirect("dashboard:home")

    # Уникальный slug
    base_slug = slugify(name) or "restaurant"
    slug = base_slug
    if Restaurant.objects.filter(slug=slug).exists():
        slug = f"{base_slug}-{uuid.uuid4().hex[:6]}"

    restaurant = Restaurant.objects.create(name_ru=name, slug=slug, is_active=True)
    Membership.objects.create(user=request.user, restaurant=restaurant)

    branch = Branch.objects.create(restaurant=restaurant, name_ru=name, is_active=True)

    menu_set = MenuSet.objects.create(restaurant=restaurant, name="Основное меню", is_active=True)
    BranchMenuSet.objects.create(branch=branch, menu_set=menu_set)

    messages.success(request, f"Ресторан «{name}» создан")
    return redirect("dashboard:restaurant_edit", restaurant_id=restaurant.id)


@login_required(login_url="dashboard:login")
def restaurant_edit(request, restaurant_id):
    restaurant = get_object_or_404(Restaurant, id=restaurant_id)
    if not Membership.objects.filter(user=request.user, restaurant=restaurant).exists():
        return redirect("dashboard:home")

    if request.method == "POST":
        name = request.POST.get("name_ru", "").strip()
        if name:
            restaurant.name_ru = name
        restaurant.about_ru     = request.POST.get("about_ru", "").strip()
        restaurant.external_url = request.POST.get("external_url", "").strip()
        restaurant.phone        = request.POST.get("phone", "").strip()
        restaurant.whatsapp     = request.POST.get("whatsapp", "").strip()
        restaurant.instagram    = request.POST.get("instagram", "").strip()
        restaurant.telegram     = request.POST.get("telegram", "").strip()
        restaurant.map_url      = request.POST.get("map_url", "").strip()
        restaurant.tiktok       = request.POST.get("tiktok", "").strip()

        logo = request.FILES.get("logo")
        if logo:
            restaurant.logo = logo

        restaurant.save()
        messages.success(request, "Данные ресторана сохранены")
        return redirect("dashboard:restaurant_edit", restaurant_id=restaurant.id)

    from printing.models import RestaurantPrintConfig, PrinterGroup
    print_cfg, _ = RestaurantPrintConfig.objects.get_or_create(restaurant=restaurant)
    printer_groups = PrinterGroup.objects.filter(restaurant=restaurant).prefetch_related("printers")

    return render(request, "dashboard/restaurant_edit.html", {
        "restaurant": restaurant,
        "print_cfg": print_cfg,
        "printer_groups": printer_groups,
    })


# ── PRINT CONFIG SAVE ─────────────────────────────────────────────────────────

@require_POST
@login_required(login_url="dashboard:login")
def restaurant_print_save(request, restaurant_id):
    from printing.models import RestaurantPrintConfig, PrinterGroup, Printer
    restaurant = get_object_or_404(Restaurant, id=restaurant_id)
    if not Membership.objects.filter(user=request.user, restaurant=restaurant).exists():
        return redirect("dashboard:home")

    cfg, _ = RestaurantPrintConfig.objects.get_or_create(restaurant=restaurant)
    cfg.enabled = request.POST.get("printing_enabled") == "on"

    # Принтер итоговых чеков
    receipt_group_id = request.POST.get("receipt_printer_group_id") or None
    if receipt_group_id:
        try:
            cfg.receipt_printer_group = PrinterGroup.objects.get(
                id=int(receipt_group_id), restaurant=restaurant
            )
        except (PrinterGroup.DoesNotExist, ValueError):
            cfg.receipt_printer_group = None
    else:
        cfg.receipt_printer_group = None
    cfg.save()

    # Сохраняем группы принтеров
    group_codes = request.POST.getlist("group_code")
    group_names = request.POST.getlist("group_display")
    printer_names = request.POST.getlist("printer_windows_name")

    for code, display, win_name in zip(group_codes, group_names, printer_names):
        code = code.strip().lower()
        display = display.strip()
        win_name = win_name.strip()
        if not code or not display:
            continue
        group, _ = PrinterGroup.objects.get_or_create(
            restaurant=restaurant, name=code,
            defaults={"display_name": display},
        )
        group.display_name = display
        group.save(update_fields=["display_name"])
        if win_name:
            Printer.objects.update_or_create(
                restaurant=restaurant, group=group,
                defaults={"windows_name": win_name, "is_active": True},
            )

    messages.success(request, "Настройки печати сохранены")
    return redirect("dashboard:restaurant_edit", restaurant_id=restaurant.id)


# ── PRINT GROUP DELETE ────────────────────────────────────────────────────────

@require_POST
@login_required(login_url="dashboard:login")
def restaurant_print_group_delete(request, restaurant_id, group_id):
    from printing.models import PrinterGroup
    restaurant = get_object_or_404(Restaurant, id=restaurant_id)
    if not Membership.objects.filter(user=request.user, restaurant=restaurant).exists():
        return redirect("dashboard:home")
    PrinterGroup.objects.filter(id=group_id, restaurant=restaurant).delete()
    return redirect("dashboard:restaurant_edit", restaurant_id=restaurant.id)


# ── DOWNLOAD PRINT CONFIG & AGENT ─────────────────────────────────────────────

@login_required(login_url="dashboard:login")
def restaurant_print_download_config(request, restaurant_id):
    """Скачать готовый config.json для агента."""
    import json as _json
    from printing.models import RestaurantPrintConfig, PrinterGroup, Printer
    restaurant = get_object_or_404(Restaurant, id=restaurant_id)
    if not Membership.objects.filter(user=request.user, restaurant=restaurant).exists():
        return redirect("dashboard:home")

    cfg, _ = RestaurantPrintConfig.objects.get_or_create(restaurant=restaurant)
    groups = PrinterGroup.objects.filter(restaurant=restaurant).prefetch_related("printers")

    printers = {}
    for g in groups:
        first = g.printers.filter(is_active=True).first()
        printers[g.name] = first.windows_name if first else "Имя принтера в Windows"

    server_url = request.build_absolute_uri("/").rstrip("/")

    data = {
        "server_url": server_url,
        "token": cfg.token,
        "poll_interval": 3,
        "heartbeat_interval": 30,
        "printers": printers if printers else {"kitchen": "XPrinter XP-80C"},
    }

    content = _json.dumps(data, ensure_ascii=False, indent=2)
    response = HttpResponse(content, content_type="application/json")
    response["Content-Disposition"] = 'attachment; filename="config.json"'
    return response


@login_required(login_url="dashboard:login")
def restaurant_print_download_agent(request, restaurant_id):
    """Отдаёт актуальный agent.py из printer_agent/."""
    restaurant = get_object_or_404(Restaurant, id=restaurant_id)
    if not Membership.objects.filter(user=request.user, restaurant=restaurant).exists():
        return redirect("dashboard:home")

    from pathlib import Path as _Path
    agent_path = _Path(__file__).resolve().parent / "agent.py"
    try:
        content = agent_path.read_bytes()
    except FileNotFoundError:
        from django.http import HttpResponseServerError
        return HttpResponseServerError("agent.py не найден на сервере")

    response = HttpResponse(content, content_type="text/x-python; charset=utf-8")
    response["Content-Disposition"] = 'attachment; filename="agent.py"'
    return response


# ── CATEGORY PRINTER GROUP ────────────────────────────────────────────────────

@require_POST
@login_required(login_url="dashboard:login")
@require_POST
@login_required(login_url="dashboard:login")
def item_printer_group(request, bci_id):
    """AJAX: назначить группу принтера отдельному блюду (BranchCategoryItem)."""
    from printing.models import PrinterGroup
    bci = get_object_or_404(BranchCategoryItem, id=bci_id)
    if not _has_branch_access(request.user, bci.branch_category.branch):
        return JsonResponse({"ok": False}, status=403)

    group_id = request.POST.get("group_id") or None
    if group_id:
        try:
            group = PrinterGroup.objects.get(
                id=group_id, restaurant=bci.branch_category.branch.restaurant
            )
            bci.printer_group = group
        except PrinterGroup.DoesNotExist:
            return JsonResponse({"ok": False, "error": "Группа не найдена"})
    else:
        bci.printer_group = None

    bci.save(update_fields=["printer_group"])
    return JsonResponse({"ok": True})


@require_POST
@login_required(login_url="dashboard:login")
def category_printer_group(request, bc_id):
    """AJAX: назначить группу принтера категории."""
    from printing.models import PrinterGroup
    bc = get_object_or_404(BranchCategory, id=bc_id)
    if not _has_branch_access(request.user, bc.branch):
        return JsonResponse({"ok": False}, status=403)

    group_id = request.POST.get("group_id") or None
    if group_id:
        try:
            group = PrinterGroup.objects.get(
                id=group_id, restaurant=bc.branch.restaurant
            )
            bc.printer_group = group
        except PrinterGroup.DoesNotExist:
            return JsonResponse({"ok": False, "error": "Группа не найдена"})
    else:
        bc.printer_group = None

    bc.save(update_fields=["printer_group"])
    return JsonResponse({"ok": True})


# ── BRANCH SETTINGS ──────────────────────────────────────────────────────────

@login_required(login_url="dashboard:login")
def branch_edit(request, branch_id):
    branch = get_object_or_404(Branch, id=branch_id)
    if not _has_branch_access(request.user, branch):
        return redirect("dashboard:home")

    if request.method == "POST":
        def dec(key, default="0"):
            try:
                return Decimal(request.POST.get(key) or default)
            except InvalidOperation:
                return Decimal(default)

        branch.delivery_enabled          = request.POST.get("delivery_enabled") == "on"
        branch.min_order_amount          = dec("min_order_amount")
        branch.delivery_fee              = dec("delivery_fee")
        branch.pos_delivery_fee_enabled  = request.POST.get("pos_delivery_fee_enabled") == "on"
        branch.free_delivery_from        = dec("free_delivery_from")
        branch.is_open_24h         = request.POST.get("is_open_24h") == "on"
        branch.pay_cash_enabled    = request.POST.get("pay_cash_enabled") == "on"
        branch.pay_online_enabled  = request.POST.get("pay_online_enabled") == "on"
        branch.print_on_accept     = request.POST.get("print_on_accept") == "on"

        ot = request.POST.get("open_time", "").strip()
        ct = request.POST.get("close_time", "").strip()
        branch.open_time  = ot or None
        branch.close_time = ct or None
        work_days_list = request.POST.getlist("work_days")
        branch.work_days = ",".join(work_days_list)

        branch.external_url = request.POST.get("external_url", "").strip()

        # Тему оформления меняет только администратор: это платная доп. услуга,
        # и неверный код просто вернул бы филиал на стандартное меню.
        if request.user.is_superuser and "template_slug" in request.POST:
            branch.template_slug = request.POST.get("template_slug", "").strip()

        lat_raw = request.POST.get("lat", "").strip()
        lon_raw = request.POST.get("lon", "").strip()
        branch.lat = lat_raw if lat_raw else None
        branch.lon = lon_raw if lon_raw else None

        photo = request.FILES.get("promo_photo")
        if photo:
            branch.promo_photo = photo

        cover = request.FILES.get("cover_photo")
        if cover:
            branch.cover_photo = cover

        branch.save()

        c = getattr(branch, "photo_compression", None)
        if c:
            messages.success(
                request,
                f"Настройки сохранены | Фото акции: {c['before_kb']} KB → {c['after_kb']} KB "
                f"(−{c['saved_pct']}%, {c['orig_size']} → {c['new_size']})"
            )
        else:
            messages.success(request, "Настройки филиала сохранены")
        return redirect("dashboard:branch_edit", branch_id=branch.id)

    work_days_list = branch.work_days.split(",") if branch.work_days else ["0","1","2","3","4","5","6"]
    return render(request, "dashboard/branch_edit.html", {
        "branch": branch,
        "work_days_list": work_days_list,
    })


# ── BRANCH MENU (prices + list) ───────────────────────────────────────────────

@login_required(login_url="dashboard:login")
def branch_items(request, branch_id):
    branch = get_object_or_404(Branch, id=branch_id)
    if not _has_branch_access(request.user, branch):
        return redirect("dashboard:home")

    categories = (
        BranchCategory.objects
        .filter(branch=branch, is_active=True)
        .select_related("category")
        .order_by("sort_order", "id")
    )

    from printing.models import PrinterGroup
    printer_groups = list(PrinterGroup.objects.filter(restaurant=branch.restaurant))

    menu = []
    for bc in categories:
        items = (
            BranchCategoryItem.objects
            .filter(branch_category=bc)
            .select_related("branch_item__item", "printer_group")
            .order_by("sort_order", "id")
        )
        menu.append({"category": bc, "items": list(items)})

    return render(request, "dashboard/branch_items.html", {
        "branch": branch,
        "menu": menu,
        "printer_groups": printer_groups,
    })


# ── ADD ITEM ─────────────────────────────────────────────────────────────────

@login_required(login_url="dashboard:login")
def item_add(request, branch_id):
    branch = get_object_or_404(Branch, id=branch_id)
    if not _has_branch_access(request.user, branch):
        return redirect("dashboard:home")

    restaurant = branch.restaurant
    categories = (
        BranchCategory.objects
        .filter(branch=branch, is_active=True)
        .select_related("category")
        .order_by("sort_order", "id")
    )

    if request.method == "POST":
        name = request.POST.get("name_ru", "").strip()
        if not name:
            messages.error(request, "Укажите название блюда")
            return redirect("dashboard:item_add", branch_id=branch.id)

        try:
            price = Decimal(request.POST.get("price") or "0")
        except InvalidOperation:
            price = Decimal("0")

        description = request.POST.get("description_ru", "").strip()
        photo = request.FILES.get("photo")

        # создаём Item
        item = Item(
            restaurant=restaurant,
            name_ru=name,
            name_ky=request.POST.get("name_ky", "").strip(),
            name_en=request.POST.get("name_en", "").strip(),
            description_ru=description,
            description_ky=request.POST.get("description_ky", "").strip(),
            description_en=request.POST.get("description_en", "").strip(),
            base_price=price,
            calories=_int_or_none(request.POST.get("calories")),
            protein=_decimal_or_none(request.POST.get("protein")),
            fat=_decimal_or_none(request.POST.get("fat")),
            carbs=_decimal_or_none(request.POST.get("carbs")),
        )
        if photo:
            item.photo = photo
        item.save()

        # создаём BranchItem
        bi = BranchItem.objects.create(
            branch=branch,
            item=item,
            price=price,
            is_available=True,
        )

        # привязываем к категории если выбрана
        branch_cat_id = request.POST.get("branch_category_id")

        # создание новой категории inline
        if branch_cat_id == "__new__":
            new_cat_ru = request.POST.get("new_cat_ru", "").strip()
            if new_cat_ru:
                # Ищем или создаём глобальную Category в MenuSet ресторана
                menu_set = MenuSet.objects.filter(restaurant=restaurant).first()
                if not menu_set:
                    menu_set = MenuSet.objects.create(restaurant=restaurant, name="Меню")
                # Привязываем MenuSet к филиалу если ещё не привязан
                BranchMenuSet.objects.get_or_create(branch=branch, menu_set=menu_set)
                cat, _ = Category.objects.get_or_create(
                    menu_set=menu_set,
                    name_ru=new_cat_ru,
                    defaults={
                        "name_ky": request.POST.get("new_cat_ky", "").strip() or new_cat_ru,
                        "name_en": request.POST.get("new_cat_en", "").strip() or new_cat_ru,
                    },
                )
                max_order = BranchCategory.objects.filter(branch=branch).aggregate(m=Max("sort_order"))["m"] or 0
                bc, _ = BranchCategory.objects.get_or_create(
                    branch=branch,
                    category=cat,
                    defaults={"sort_order": max_order + 1, "is_active": True},
                )
                BranchCategoryItem.objects.get_or_create(
                    branch_category=bc, branch_item=bi, defaults={"sort_order": 0}
                )
                ItemCategory.objects.get_or_create(item=item, category=cat, defaults={"sort_order": 0})
            else:
                ensure_links_for_branch_item(bi)

        elif branch_cat_id:
            try:
                bc = BranchCategory.objects.get(id=branch_cat_id, branch=branch)
                ItemCategory.objects.get_or_create(
                    item=item, category=bc.category, defaults={"sort_order": 0}
                )
                BranchCategoryItem.objects.get_or_create(
                    branch_category=bc, branch_item=bi, defaults={"sort_order": 0}
                )
            except BranchCategory.DoesNotExist:
                pass
        else:
            ensure_links_for_branch_item(bi)

        messages.success(request, f"Блюдо «{name}» добавлено")
        return redirect("dashboard:branch_items", branch_id=branch.id)

    return render(request, "dashboard/item_add.html", {
        "branch": branch,
        "categories": categories,
    })


# ── EDIT ITEM ─────────────────────────────────────────────────────────────────

@login_required(login_url="dashboard:login")
def item_edit(request, branch_item_id):
    bi = get_object_or_404(BranchItem, id=branch_item_id)
    if not _has_branch_access(request.user, bi.branch):
        return redirect("dashboard:home")

    item = bi.item
    branch = bi.branch

    current_bci = bi.categories_in_branch.select_related("branch_category").first()
    current_cat_id = current_bci.branch_category_id if current_bci else None

    # Текущая категория блюда должна попасть в список выбора, даже если она
    # скрыта (is_active=False) — иначе <select> не сможет показать её выбранной,
    # по умолчанию откатится на «Без категории», и ЛЮБОЕ сохранение формы
    # (хоть просто ради скидки) тихо отвяжет блюдо от категории и уберёт его
    # из меню доставки/самовывоза.
    branch_categories = (
        BranchCategory.objects
        .filter(branch=branch)
        .filter(Q(is_active=True) | Q(id=current_cat_id))
        .select_related("category")
        .order_by("sort_order", "id")
    )

    if request.method == "POST":
        name = request.POST.get("name_ru", "").strip()
        if name:
            item.name_ru = name
        item.name_ky = request.POST.get("name_ky", "").strip()
        item.name_en = request.POST.get("name_en", "").strip()
        item.description_ru = request.POST.get("description_ru", "").strip()
        item.description_ky = request.POST.get("description_ky", "").strip()
        item.description_en = request.POST.get("description_en", "").strip()
        item.calories = _int_or_none(request.POST.get("calories"))
        item.protein = _decimal_or_none(request.POST.get("protein"))
        item.fat = _decimal_or_none(request.POST.get("fat"))
        item.carbs = _decimal_or_none(request.POST.get("carbs"))

        try:
            bi.price = Decimal(request.POST.get("price") or "0")
        except InvalidOperation:
            pass

        old_price_raw = (request.POST.get("old_price") or "").strip()
        if old_price_raw:
            try:
                bi.old_price = Decimal(old_price_raw)
            except InvalidOperation:
                pass
        else:
            bi.old_price = None
        bi.promo_label = request.POST.get("promo_label", "").strip()[:20]
        bi.label = request.POST.get("label", "").strip()[:20]

        bi.is_available = request.POST.get("is_available") == "on"
        # «Только в зале» — блюдо скрыто из онлайн-меню (доставка/самовывоз),
        # но доступно по QR за столом и в кассе
        bi.delivery_available = request.POST.get("dine_in_only") != "on"

        photo = request.FILES.get("photo")
        if photo:
            item.photo = photo

        item.save()
        bi.save(update_fields=["price", "old_price", "promo_label", "label",
                               "is_available", "delivery_available", "updated_at"])

        # Update category assignment
        new_cat_id = request.POST.get("branch_category_id", "").strip()
        if new_cat_id:
            try:
                new_bc = BranchCategory.objects.get(id=int(new_cat_id), branch=branch)
                # Remove from all other categories in this branch, assign to new one
                bi.categories_in_branch.exclude(branch_category=new_bc).delete()
                BranchCategoryItem.objects.get_or_create(branch_category=new_bc, branch_item=bi)
            except (BranchCategory.DoesNotExist, ValueError):
                pass
        else:
            # "Без категории" — remove all category assignments
            bi.categories_in_branch.all().delete()

        messages.success(request, "Блюдо обновлено")
        return redirect("dashboard:branch_items", branch_id=bi.branch_id)

    return render(request, "dashboard/item_edit.html", {
        "bi": bi,
        "item": item,
        "branch_categories": branch_categories,
        "current_cat_id": current_cat_id,
    })


# ── AJAX: update price ────────────────────────────────────────────────────────

@require_POST
@login_required(login_url="dashboard:login")
def update_item_price(request, branch_item_id):
    bi = get_object_or_404(BranchItem, id=branch_item_id)
    if not _has_branch_access(request.user, bi.branch):
        return JsonResponse({"ok": False}, status=403)
    try:
        price = Decimal(request.POST.get("price", ""))
        if price < 0:
            raise ValueError
    except Exception:
        return JsonResponse({"ok": False, "error": "Некорректная цена"})

    bi.price = price
    bi.save(update_fields=["price", "updated_at"])
    return JsonResponse({"ok": True, "price": str(bi.price)})


# ── AJAX: toggle availability ─────────────────────────────────────────────────

@require_POST
@login_required(login_url="dashboard:login")
def toggle_item(request, branch_item_id):
    bi = get_object_or_404(BranchItem, id=branch_item_id)
    if not _has_branch_access(request.user, bi.branch):
        return JsonResponse({"ok": False}, status=403)

    bi.is_available = not bi.is_available
    bi.save(update_fields=["is_available", "updated_at"])
    return JsonResponse({"ok": True, "is_available": bi.is_available})


# ── PROMO CODES ───────────────────────────────────────────────────────────────

@login_required(login_url="dashboard:login")
def promo_list(request, branch_id):
    branch = get_object_or_404(Branch, id=branch_id)
    if not _has_branch_access(request.user, branch):
        return redirect("dashboard:home")

    if request.method == "POST":
        code = request.POST.get("code", "").strip().upper()
        discount_type = request.POST.get("discount_type", "")
        discount_value = Decimal(request.POST.get("discount_value") or "0")
        valid_until = request.POST.get("valid_until") or None
        max_uses = int(request.POST.get("max_uses") or 0)

        if not code:
            messages.error(request, "Введите промокод")
        elif PromoCode.objects.filter(branch=branch, code=code).exists():
            messages.error(request, f"Промокод «{code}» уже существует")
        else:
            PromoCode.objects.create(
                branch=branch,
                code=code,
                discount_type=discount_type,
                discount_value=discount_value,
                valid_until=valid_until,
                max_uses=max_uses,
                is_active=True,
            )
            messages.success(request, f"Промокод «{code}» создан")
        return redirect("dashboard:promo_list", branch_id=branch.id)

    promos = PromoCode.objects.filter(branch=branch).order_by("-created_at")
    today = timezone.localdate()
    return render(request, "dashboard/promo_list.html", {
        "branch": branch,
        "promos": promos,
        "today": today,
        "discount_types": PromoCode.DiscountType.choices,
    })


@require_POST
@login_required(login_url="dashboard:login")
def promo_toggle(request, promo_id):
    promo = get_object_or_404(PromoCode, id=promo_id)
    if not _has_branch_access(request.user, promo.branch):
        return redirect("dashboard:home")
    promo.is_active = not promo.is_active
    promo.save(update_fields=["is_active", "updated_at"])
    return redirect("dashboard:promo_list", branch_id=promo.branch_id)


@require_POST
@login_required(login_url="dashboard:login")
def promo_delete(request, promo_id):
    promo = get_object_or_404(PromoCode, id=promo_id)
    if not _has_branch_access(request.user, promo.branch):
        return redirect("dashboard:home")
    promo.delete()
    messages.success(request, "Промокод удалён")
    return redirect("dashboard:promo_list", branch_id=promo.branch_id)



# ── ANALYTICS ────────────────────────────────────────────────────────────────

@login_required(login_url="dashboard:login")
def analytics(request):
    from orders.models import Order
    from shops.models import StoreOrder, StoreMembership
    from pharmacy.models import PharmacyOrder, PharmacyMembership
    from hotels.models import HotelBooking, HotelMembership
    from barbershop.models import Appointment as BarberAppointment, BarbershopMembership
    from karaoke.models import KaraokeBooking, KaraokeMembership
    from simracing.models import SimRacingAppointment, SimRacingMembership
    from printshop.models import PrintOrder, PrintMembership
    from realestate.models import RealtyMembership
    from agency.models import AgencyMembership
    from django.db.models import Sum

    user     = request.user
    is_super = user.is_superuser

    now = timezone.now()
    period = request.GET.get("period", "30")
    try:
        days = int(period)
    except ValueError:
        days = 30
    days = max(1, min(days, 365))
    since = now - timedelta(days=days)

    # ── ID организаций пользователя ───────────────────────────────────────────
    if is_super:
        my_restaurant_ids = my_hotel_ids = my_store_ids = my_pharmacy_ids = None
        my_barber_ids = my_karaoke_ids = my_simracing_ids = my_printshop_ids = None
        my_realty_ids = my_agency_ids = None
    else:
        my_restaurant_ids = list(Membership.objects.filter(user=user).values_list("restaurant_id", flat=True))
        my_hotel_ids      = list(HotelMembership.objects.filter(user=user).values_list("hotel_id", flat=True))
        my_store_ids      = list(StoreMembership.objects.filter(user=user).values_list("store_id", flat=True))
        my_pharmacy_ids   = list(PharmacyMembership.objects.filter(user=user).values_list("pharmacy_id", flat=True))
        my_barber_ids     = list(BarbershopMembership.objects.filter(user=user).values_list("barbershop_id", flat=True))
        my_karaoke_ids    = list(KaraokeMembership.objects.filter(user=user).values_list("venue_id", flat=True))
        my_simracing_ids  = list(SimRacingMembership.objects.filter(user=user).values_list("venue_id", flat=True))
        my_printshop_ids  = list(PrintMembership.objects.filter(user=user).values_list("center_id", flat=True))
        my_realty_ids     = list(RealtyMembership.objects.filter(user=user).values_list("agency_id", flat=True))
        my_agency_ids     = list(AgencyMembership.objects.filter(user=user).values_list("agency_id", flat=True))

    # ── Посещаемость ──────────────────────────────────────────────────────────
    pv_qs = PageView.objects.filter(timestamp__gte=since)

    allowed_sections = None
    if not is_super:
        allowed_sections = set()
        if my_restaurant_ids: allowed_sections.add("restaurant")
        if my_hotel_ids:      allowed_sections.add("hotels")
        if my_store_ids:      allowed_sections.add("shops")
        if my_pharmacy_ids:   allowed_sections.add("pharmacy")
        if my_barber_ids:     allowed_sections.add("barbershop")
        if my_karaoke_ids:    allowed_sections.add("karaoke")
        if my_simracing_ids:  allowed_sections.add("simracing")
        if my_printshop_ids:  allowed_sections.add("printshop")
        if my_realty_ids:     allowed_sections.add("realty")
        if my_agency_ids:     allowed_sections.add("agency")
        if allowed_sections:
            pv_qs = pv_qs.filter(section__in=allowed_sections)

    by_section = (
        pv_qs.values("section")
             .annotate(total=Count("id"), unique=Count("ip_hash", distinct=True))
             .order_by("-total")
    )
    section_labels = dict(PageView.SECTION_CHOICES)
    sections_data = [
        {
            "section": row["section"],
            "label": section_labels.get(row["section"], row["section"]),
            "total": row["total"],
            "unique": row["unique"],
        }
        for row in by_section
    ]
    total_views  = pv_qs.count()
    total_unique = pv_qs.values("ip_hash").distinct().count()

    chart_days  = min(days, 60)
    chart_since = now - timedelta(days=chart_days)
    daily_qs = (
        PageView.objects
        .filter(timestamp__gte=chart_since)
        .extra(select={"day": "DATE(timestamp)"})
        .values("day")
        .annotate(cnt=Count("id"))
        .order_by("day")
    )
    if not is_super and allowed_sections:
        daily_qs = daily_qs.filter(section__in=allowed_sections)
    daily_labels = [str(r["day"]) for r in daily_qs]
    daily_values = [r["cnt"] for r in daily_qs]

    # ── Базовые queryset-ы заказов / записей (уже отфильтрованы по доступу) ───
    def _scope(model, field, ids):
        return model.objects.all() if is_super else model.objects.filter(**{f"{field}__in": ids or []})

    rest_qs   = _scope(Order,                "branch__restaurant_id", my_restaurant_ids)
    shop_qs   = _scope(StoreOrder,           "branch__store_id",      my_store_ids)
    ph_qs     = _scope(PharmacyOrder,        "branch__pharmacy_id",   my_pharmacy_ids)
    hotel_qs  = _scope(HotelBooking,         "branch__hotel_id",      my_hotel_ids)
    barber_qs = _scope(BarberAppointment,    "barbershop_id",         my_barber_ids)
    krk_qs    = _scope(KaraokeBooking,       "venue_id",              my_karaoke_ids)
    sim_qs    = _scope(SimRacingAppointment, "venue_id",              my_simracing_ids)
    print_qs  = _scope(PrintOrder,           "branch__center_id",     my_printshop_ids)

    def _agg(qs, name_field, revenue_field, period_since):
        ann = {"cnt": Count("id")}
        if revenue_field:
            ann["revenue"] = Sum(revenue_field)
        rows_all = list(qs.values(name_field).annotate(**ann).order_by("-cnt"))
        total_all    = qs.count()
        total_period = qs.filter(created_at__gte=period_since).count()
        norm = [
            {"name": r[name_field] or "—", "cnt": r["cnt"], "revenue": r.get("revenue") or 0}
            for r in rows_all
        ]
        return norm, total_all, total_period

    rest_rows,   rest_ta,   rest_tp   = _agg(rest_qs,   "branch__restaurant__name_ru",  "total_amount",   since)
    shop_rows,   shop_ta,   shop_tp   = _agg(shop_qs,   "branch__store__name_ru",       "total",          since)
    ph_rows,     ph_ta,     ph_tp     = _agg(ph_qs,     "branch__pharmacy__name_ru",    "total_amount",   since)
    hotel_rows,  hotel_ta,  hotel_tp  = _agg(hotel_qs,  "branch__hotel__name_ru",       "total",          since)
    barber_rows, barber_ta, barber_tp = _agg(barber_qs, "barbershop__name",             "price_snapshot", since)
    krk_rows,    krk_ta,    krk_tp    = _agg(krk_qs,    "venue__name",                  None,             since)
    sim_rows,    sim_ta,    sim_tp    = _agg(sim_qs,    "venue__name",                  "total_price",    since)
    print_rows,  print_ta,  print_tp  = _agg(print_qs,  "branch__center__name_ru",      "total",          since)

    grand_period = rest_tp + shop_tp + ph_tp + hotel_tp + barber_tp + krk_tp + sim_tp + print_tp
    grand_all    = rest_ta + shop_ta + ph_ta + hotel_ta + barber_ta + krk_ta + sim_ta + print_ta

    all_order_sections = [
        {"icon": "🍽",  "label": "Рестораны",  "total_period": rest_tp,   "total_all": rest_ta,   "rows_all": rest_rows},
        {"icon": "🏪",  "label": "Магазины",   "total_period": shop_tp,   "total_all": shop_ta,   "rows_all": shop_rows},
        {"icon": "💊",  "label": "Аптеки",     "total_period": ph_tp,     "total_all": ph_ta,     "rows_all": ph_rows},
        {"icon": "🏨",  "label": "Отели",      "total_period": hotel_tp,  "total_all": hotel_ta,  "rows_all": hotel_rows},
        {"icon": "✂️",  "label": "Барбершопы", "total_period": barber_tp, "total_all": barber_ta, "rows_all": barber_rows},
        {"icon": "🎤",  "label": "Караоке",    "total_period": krk_tp,    "total_all": krk_ta,    "rows_all": krk_rows},
        {"icon": "🏎️",  "label": "Картинг", "total_period": sim_tp,    "total_all": sim_ta,    "rows_all": sim_rows},
        {"icon": "🖨️",  "label": "Полиграфия", "total_period": print_tp,  "total_all": print_ta,  "rows_all": print_rows},
    ]

    # Обычный пользователь видит только разделы, к которым у него есть доступ и данные
    if not is_super:
        order_sections = [s for s in all_order_sections if s["total_all"] > 0]
    else:
        order_sections = all_order_sections

    return render(request, "dashboard/analytics.html", {
        "period": days,
        "is_super": is_super,
        "sections_data": sections_data,
        "total_views": total_views,
        "total_unique": total_unique,
        "daily_labels": daily_labels,
        "daily_values": daily_values,
        "order_sections": order_sections,
        "grand_period": grand_period,
        "grand_all": grand_all,
    })


# ── БАЗА КЛИЕНТОВ ────────────────────────────────────────────────────────────

@login_required(login_url="dashboard:login")
def clients(request):
    """Единая база клиентов по всем бизнесам пользователя. Суперадмин — все клиенты."""
    import re
    from django.db.models import Q, F, Func, Value
    from orders.models import Order
    from shops.models import StoreOrder, StoreMembership
    from pharmacy.models import PharmacyOrder, PharmacyMembership
    from hotels.models import HotelBooking, HotelMembership
    from barbershop.models import Appointment as BarberAppointment, BarbershopMembership
    from karaoke.models import KaraokeBooking, KaraokeMembership
    from simracing.models import SimRacingAppointment, SimRacingMembership
    from printshop.models import PrintOrder, PrintMembership

    user = request.user
    is_super = user.is_superuser
    q = (request.GET.get("q") or "").strip()
    digits = re.sub(r"\D", "", q)
    # локальный номер (последние 9 цифр) — чтобы «+996 700…», «0700…», «700…» совпадали
    phone_tail = digits[-9:] if len(digits) >= 9 else digits

    if is_super:
        ids = {}
    else:
        ids = {
            "rest":   list(Membership.objects.filter(user=user).values_list("restaurant_id", flat=True)),
            "shop":   list(StoreMembership.objects.filter(user=user).values_list("store_id", flat=True)),
            "ph":     list(PharmacyMembership.objects.filter(user=user).values_list("pharmacy_id", flat=True)),
            "hotel":  list(HotelMembership.objects.filter(user=user).values_list("hotel_id", flat=True)),
            "barber": list(BarbershopMembership.objects.filter(user=user).values_list("barbershop_id", flat=True)),
            "krk":    list(KaraokeMembership.objects.filter(user=user).values_list("venue_id", flat=True)),
            "sim":    list(SimRacingMembership.objects.filter(user=user).values_list("venue_id", flat=True)),
            "print":  list(PrintMembership.objects.filter(user=user).values_list("center_id", flat=True)),
        }

    #  key,      label,        icon, Model,               scope_field,             name,            phone,            amount,           org_name
    SOURCES = [
        ("rest",  "Ресторан",   "🍽",  Order,               "branch__restaurant_id", "customer_name", "customer_phone", "total_amount",   "branch__restaurant__name_ru"),
        ("shop",  "Магазин",    "🏪",  StoreOrder,          "branch__store_id",      "name",          "phone",          "total",          "branch__store__name_ru"),
        ("ph",    "Аптека",     "💊",  PharmacyOrder,       "branch__pharmacy_id",   "customer_name", "customer_phone", "total_amount",   "branch__pharmacy__name_ru"),
        ("hotel", "Отель",      "🏨",  HotelBooking,        "branch__hotel_id",      "customer_name", "customer_phone", "total",          "branch__hotel__name_ru"),
        ("barber","Барбершоп",  "✂️",  BarberAppointment,   "barbershop_id",         "customer_name", "customer_phone", "price_snapshot", "barbershop__name"),
        ("krk",   "Караоке",    "🎤",  KaraokeBooking,      "venue_id",              "customer_name", "customer_phone", None,             "venue__name"),
        ("sim",   "Картинг", "🏎️",  SimRacingAppointment,"venue_id",              "customer_name", "customer_phone", "total_price",    "venue__name"),
        ("print", "Полиграфия", "🖨️",  PrintOrder,          "branch__center_id",     "name",          "phone",          "total",          "branch__center__name_ru"),
    ]

    cap = 400 if q else 120
    cmap = {}
    for key, label, icon, Model, scope_field, nf, pf, af, orgf in SOURCES:
        if not is_super and not ids.get(key):
            continue
        qs = Model.objects.all() if is_super else Model.objects.filter(**{f"{scope_field}__in": ids[key]})
        if q:
            if len(digits) >= 3:
                # сравниваем только цифры телефона — чтобы «+996 700…», «0700…», «700…» находились одинаково
                qs = qs.annotate(_pd=Func(F(pf), Value(r"[^0-9]"), Value(""), Value("g"),
                                          function="regexp_replace"))
                qs = qs.filter(Q(**{f"{nf}__icontains": q}) | Q(_pd__icontains=phone_tail))
            else:
                qs = qs.filter(Q(**{f"{nf}__icontains": q}) | Q(**{f"{pf}__icontains": q}))
        vals = [nf, pf, "created_at", orgf, "id", "status"]
        if af:
            vals.append(af)
        for r in qs.order_by("-created_at").values(*vals)[:cap]:
            name  = (r.get(nf) or "").strip()
            phone = (r.get(pf) or "").strip()
            pdig  = re.sub(r"\D", "", phone)[-9:]
            gkey  = pdig or ("n:" + name.lower())
            if not name and not pdig:
                continue
            c = cmap.setdefault(gkey, {"phone": "", "names": set(), "orgs": set(),
                                       "count": 0, "sum": 0.0, "last": None, "records": []})
            if name:
                c["names"].add(name)
            if phone and not c["phone"]:
                c["phone"] = phone
            org = r.get(orgf) or "—"
            c["orgs"].add(f"{icon} {org}")
            amt = float(r.get(af) or 0) if af else 0.0
            c["count"] += 1
            c["sum"]   += amt
            dt = r.get("created_at")
            if dt and (c["last"] is None or dt > c["last"]):
                c["last"] = dt
            c["records"].append({"biz": label, "icon": icon, "org": org,
                                 "date": dt, "amount": amt, "status": r.get("status") or ""})

    def _ts(d):
        return d.timestamp() if d else 0

    clients_list = []
    for gkey, c in cmap.items():
        c["records"].sort(key=lambda x: _ts(x["date"]), reverse=True)
        clients_list.append({
            "phone":   c["phone"] or "—",
            "name":    " / ".join(sorted(c["names"])[:3]) or "Без имени",
            "orgs":    sorted(c["orgs"]),
            "count":   c["count"],
            "sum":     c["sum"],
            "last":    c["last"],
            "records": c["records"][:60],
        })
    clients_list.sort(key=lambda x: _ts(x["last"]), reverse=True)

    return render(request, "dashboard/clients.html", {
        "q": q,
        "is_super": is_super,
        "clients": clients_list[:100],
        "total_found": len(clients_list),
    })


# ── ORDERS ANALYTICS ─────────────────────────────────────────────────────────

@login_required(login_url="dashboard:login")
def orders_analytics(request):
    from orders.models import Order, OrderItem
    from django.db.models import Sum, Count
    from django.utils import timezone
    from datetime import timedelta, date

    user     = request.user
    is_super = user.is_superuser

    # ── фильтры ──────────────────────────────────────────────────────────────
    period = request.GET.get("period", "30")
    try:
        days = int(period)
    except ValueError:
        days = 30
    days = max(1, min(days, 365))

    now   = timezone.now()
    since = now - timedelta(days=days)

    # ── доступные рестораны ───────────────────────────────────────────────────
    if is_super:
        restaurants = Restaurant.objects.filter(branches__orders__isnull=False).distinct().order_by("name_ru")
        restaurant_id = request.GET.get("restaurant")
        if restaurant_id and restaurant_id.isdigit():
            order_qs = Order.objects.filter(branch__restaurant_id=int(restaurant_id))
        else:
            order_qs = Order.objects.all()
            restaurant_id = None
    else:
        my_ids = list(Membership.objects.filter(user=user).values_list("restaurant_id", flat=True))
        restaurants = Restaurant.objects.filter(id__in=my_ids).order_by("name_ru")
        order_qs    = Order.objects.filter(branch__restaurant_id__in=my_ids)
        restaurant_id = None

    # ── применяем фильтр по периоду ───────────────────────────────────────────
    order_qs_period = order_qs.filter(created_at__gte=since)

    # ── разделение: доставка / в заведении ───────────────────────────────────
    delivery_count = order_qs_period.filter(type=Order.Type.DELIVERY).count()
    inplace_count  = order_qs_period.exclude(type=Order.Type.DELIVERY).count()

    otype = request.GET.get("otype", "all")
    if otype == "delivery":
        order_qs_period = order_qs_period.filter(type=Order.Type.DELIVERY)
    elif otype == "inplace":
        order_qs_period = order_qs_period.exclude(type=Order.Type.DELIVERY)
    else:
        otype = "all"

    # ── KPI ──────────────────────────────────────────────────────────────────
    total_orders  = order_qs_period.count()
    # Выручка — только стоимость блюд (без доставки)
    total_revenue = (
        OrderItem.objects
        .filter(order__in=order_qs_period)
        .aggregate(s=Sum("line_total"))["s"] or 0
    )
    total_items   = (
        OrderItem.objects
        .filter(order__in=order_qs_period)
        .aggregate(s=Sum("qty"))["s"] or 0
    )

    # ── топ блюд за период ────────────────────────────────────────────────────
    top_items = (
        OrderItem.objects
        .filter(order__in=order_qs_period)
        .values("item__name_ru")
        .annotate(qty_total=Sum("qty"), order_count=Count("order", distinct=True))
        .order_by("-qty_total")[:30]
    )

    # ── динамика по дням ──────────────────────────────────────────────────────
    chart_days  = min(days, 60)
    chart_since = now - timedelta(days=chart_days)
    chart_qs = order_qs.filter(created_at__gte=chart_since)
    if otype == "delivery":
        chart_qs = chart_qs.filter(type=Order.Type.DELIVERY)
    elif otype == "inplace":
        chart_qs = chart_qs.exclude(type=Order.Type.DELIVERY)
    daily_qs = (
        chart_qs
        .extra(select={"day": 'DATE("orders_order"."created_at")'})
        .values("day")
        .annotate(cnt=Count("id", distinct=True), revenue=Sum("items__line_total"))
        .order_by("day")
    )
    chart_labels  = [str(r["day"]) for r in daily_qs]
    chart_orders  = [r["cnt"] for r in daily_qs]
    chart_revenue = [float(r["revenue"] or 0) for r in daily_qs]

    # ── список всех заказов (пагинация) ───────────────────────────────────────
    from django.core.paginator import Paginator

    orders_list = (
        order_qs_period
        .select_related("branch", "branch__restaurant")
        .prefetch_related("items__item")
        .annotate(items_total=Sum("items__line_total"))
        .order_by("-created_at")
    )
    paginator = Paginator(orders_list, 30)
    page_num  = request.GET.get("page", 1)
    page_obj  = paginator.get_page(page_num)

    return render(request, "dashboard/orders.html", {
        "period":        days,
        "is_super":      is_super,
        "restaurants":   restaurants,
        "restaurant_id": restaurant_id,
        "total_orders":  total_orders,
        "total_revenue": total_revenue,
        "total_items":   total_items,
        "top_items":     list(top_items),
        "chart_labels":  chart_labels,
        "chart_orders":  chart_orders,
        "chart_revenue": chart_revenue,
        "page_obj":      page_obj,
        "otype":          otype,
        "delivery_count": delivery_count,
        "inplace_count":  inplace_count,
    })


# ── CATEGORIES ────────────────────────────────────────────────────────────────

@login_required(login_url="dashboard:login")
def branch_categories(request, branch_id):
    branch = get_object_or_404(Branch, id=branch_id)
    if not _has_branch_access(request.user, branch):
        return redirect("dashboard:home")

    active_bcs = list(
        BranchCategory.objects
        .filter(branch=branch)
        .select_related("category__menu_set", "printer_group")
        .order_by("sort_order", "id")
    )
    added_cat_ids = {bc.category_id for bc in active_bcs}

    all_cats = (
        Category.objects
        .filter(menu_set__restaurant=branch.restaurant)
        .select_related("menu_set")
        .order_by("menu_set__name", "name_ru")
    )
    available_cats = [c for c in all_cats if c.id not in added_cat_ids]

    from printing.models import PrinterGroup
    printer_groups = list(PrinterGroup.objects.filter(restaurant=branch.restaurant))

    return render(request, "dashboard/branch_categories.html", {
        "branch": branch,
        "categories": active_bcs,
        "available_cats": available_cats,
        "printer_groups": printer_groups,
    })


@require_POST
@login_required(login_url="dashboard:login")
def category_add(request, branch_id):
    branch = get_object_or_404(Branch, id=branch_id)
    if not _has_branch_access(request.user, branch):
        return JsonResponse({"ok": False}, status=403)

    category_id = request.POST.get("category_id")
    try:
        cat = Category.objects.select_related("menu_set").get(
            id=category_id, menu_set__restaurant=branch.restaurant
        )
        max_order = BranchCategory.objects.filter(branch=branch).aggregate(
            m=Max("sort_order")
        )["m"] or 0
        bc, created = BranchCategory.objects.get_or_create(
            branch=branch,
            category=cat,
            defaults={"sort_order": max_order + 10, "is_active": True},
        )
        return JsonResponse({
            "ok": True,
            "bc_id": bc.id,
            "cat_id": cat.id,
            "name": cat.name_ru,
            "menu_set": cat.menu_set.name,
            "sort_order": bc.sort_order,
            "is_active": bc.is_active,
        })
    except Category.DoesNotExist:
        return JsonResponse({"ok": False, "error": "Категория не найдена"})


@require_POST
@login_required(login_url="dashboard:login")
def category_create(request, branch_id):
    """Create a brand-new Category for the restaurant and add it to the branch."""
    branch = get_object_or_404(Branch, id=branch_id)
    if not _has_branch_access(request.user, branch):
        return JsonResponse({"ok": False}, status=403)

    name_ru = request.POST.get("name_ru", "").strip()
    if not name_ru:
        return JsonResponse({"ok": False, "error": "Введите название категории"})

    name_ky = request.POST.get("name_ky", "").strip()
    name_en = request.POST.get("name_en", "").strip()

    menu_set = (
        MenuSet.objects.filter(restaurant=branch.restaurant, is_active=True)
        .order_by("id")
        .first()
    )
    if not menu_set:
        return JsonResponse({"ok": False, "error": "У ресторана нет ни одного меню-сета"})

    cat = Category.objects.create(
        menu_set=menu_set,
        name_ru=name_ru,
        name_ky=name_ky,
        name_en=name_en,
    )

    max_order = BranchCategory.objects.filter(branch=branch).aggregate(m=Max("sort_order"))["m"] or 0
    bc = BranchCategory.objects.create(
        branch=branch,
        category=cat,
        sort_order=max_order + 10,
        is_active=True,
    )

    return JsonResponse({
        "ok": True,
        "bc_id": bc.id,
        "cat_id": cat.id,
        "name": cat.name_ru,
        "menu_set": menu_set.name,
        "sort_order": bc.sort_order,
    })


@require_POST
@login_required(login_url="dashboard:login")
def category_edit(request, cat_id):
    """Edit name fields of a Category (must belong to a restaurant the user can access)."""
    cat = get_object_or_404(Category, id=cat_id)
    if not Membership.objects.filter(user=request.user, restaurant=cat.menu_set.restaurant).exists():
        return JsonResponse({"ok": False}, status=403)

    name_ru = request.POST.get("name_ru", "").strip()
    if not name_ru:
        return JsonResponse({"ok": False, "error": "Название не может быть пустым"})

    cat.name_ru = name_ru
    cat.name_ky = request.POST.get("name_ky", "").strip()
    cat.name_en = request.POST.get("name_en", "").strip()
    cat.save(update_fields=["name_ru", "name_ky", "name_en", "updated_at"])

    return JsonResponse({"ok": True, "name_ru": cat.name_ru, "name_ky": cat.name_ky, "name_en": cat.name_en})


@require_POST
@login_required(login_url="dashboard:login")
def category_toggle(request, bc_id):
    bc = get_object_or_404(BranchCategory, id=bc_id)
    if not _has_branch_access(request.user, bc.branch):
        return JsonResponse({"ok": False}, status=403)
    bc.is_active = not bc.is_active
    bc.save(update_fields=["is_active", "updated_at"])
    return JsonResponse({"ok": True, "is_active": bc.is_active})


@require_POST
@login_required(login_url="dashboard:login")
def category_reorder(request, bc_id):
    bc = get_object_or_404(BranchCategory, id=bc_id)
    if not _has_branch_access(request.user, bc.branch):
        return JsonResponse({"ok": False}, status=403)
    try:
        sort_order = int(request.POST.get("sort_order", bc.sort_order))
    except (ValueError, TypeError):
        return JsonResponse({"ok": False, "error": "invalid"})
    bc.sort_order = sort_order
    bc.save(update_fields=["sort_order", "updated_at"])
    return JsonResponse({"ok": True})


@require_POST
@login_required(login_url="dashboard:login")
def category_remove(request, bc_id):
    bc = get_object_or_404(BranchCategory, id=bc_id)
    if not _has_branch_access(request.user, bc.branch):
        return JsonResponse({"ok": False}, status=403)
    bc.delete()
    return JsonResponse({"ok": True})


# ── MENU SETS (сеты категорий) ────────────────────────────────────────────────

def _has_restaurant_access(user, restaurant):
    if user.is_superuser:
        return True
    return Membership.objects.filter(user=user, restaurant=restaurant).exists()


@login_required(login_url="dashboard:login")
def menu_sets(request, restaurant_id):
    restaurant = get_object_or_404(Restaurant, id=restaurant_id)
    if not _has_restaurant_access(request.user, restaurant):
        return redirect("dashboard:home")
    sets = (
        MenuSet.objects
        .filter(restaurant=restaurant)
        .prefetch_related("categories")
        .order_by("id")
    )
    return render(request, "dashboard/menu_sets.html", {
        "restaurant": restaurant,
        "sets": sets,
    })


@require_POST
@login_required(login_url="dashboard:login")
def menu_set_add(request, restaurant_id):
    restaurant = get_object_or_404(Restaurant, id=restaurant_id)
    if not _has_restaurant_access(request.user, restaurant):
        return JsonResponse({"ok": False}, status=403)
    name = request.POST.get("name", "").strip()
    if not name:
        return JsonResponse({"ok": False, "error": "Укажите название сета"})
    ms = MenuSet.objects.create(restaurant=restaurant, name=name, is_active=True)
    return JsonResponse({"ok": True, "id": ms.id, "name": ms.name})


@require_POST
@login_required(login_url="dashboard:login")
def menu_set_rename(request, menu_set_id):
    ms = get_object_or_404(MenuSet, id=menu_set_id)
    if not _has_restaurant_access(request.user, ms.restaurant):
        return JsonResponse({"ok": False}, status=403)
    name = request.POST.get("name", "").strip()
    if not name:
        return JsonResponse({"ok": False, "error": "Название не может быть пустым"})
    ms.name = name
    ms.save(update_fields=["name", "updated_at"])
    return JsonResponse({"ok": True, "name": ms.name})


@require_POST
@login_required(login_url="dashboard:login")
def menu_set_delete(request, menu_set_id):
    ms = get_object_or_404(MenuSet, id=menu_set_id)
    if not _has_restaurant_access(request.user, ms.restaurant):
        return JsonResponse({"ok": False}, status=403)
    ms.delete()
    return JsonResponse({"ok": True})


@require_POST
@login_required(login_url="dashboard:login")
def ms_category_add(request, menu_set_id):
    ms = get_object_or_404(MenuSet, id=menu_set_id)
    if not _has_restaurant_access(request.user, ms.restaurant):
        return JsonResponse({"ok": False}, status=403)
    name_ru = request.POST.get("name_ru", "").strip()
    if not name_ru:
        return JsonResponse({"ok": False, "error": "Укажите название категории"})
    cat = Category.objects.create(
        menu_set=ms,
        name_ru=name_ru,
        name_ky=request.POST.get("name_ky", "").strip(),
        name_en=request.POST.get("name_en", "").strip(),
    )
    return JsonResponse({"ok": True, "id": cat.id, "name_ru": cat.name_ru,
                         "name_ky": cat.name_ky, "name_en": cat.name_en})


@require_POST
@login_required(login_url="dashboard:login")
def ms_category_edit(request, category_id):
    cat = get_object_or_404(Category, id=category_id)
    if not _has_restaurant_access(request.user, cat.menu_set.restaurant):
        return JsonResponse({"ok": False}, status=403)
    name_ru = request.POST.get("name_ru", "").strip()
    if not name_ru:
        return JsonResponse({"ok": False, "error": "Название не может быть пустым"})
    cat.name_ru = name_ru
    cat.name_ky = request.POST.get("name_ky", "").strip()
    cat.name_en = request.POST.get("name_en", "").strip()
    cat.save(update_fields=["name_ru", "name_ky", "name_en", "updated_at"])
    return JsonResponse({"ok": True, "name_ru": cat.name_ru,
                         "name_ky": cat.name_ky, "name_en": cat.name_en})


@require_POST
@login_required(login_url="dashboard:login")
def ms_category_delete(request, category_id):
    cat = get_object_or_404(Category, id=category_id)
    if not _has_restaurant_access(request.user, cat.menu_set.restaurant):
        return JsonResponse({"ok": False}, status=403)
    cat.delete()
    return JsonResponse({"ok": True})


# ── TABLES (столики) ──────────────────────────────────────────────────────────

@login_required(login_url="dashboard:login")
def branch_tables(request, branch_id):
    branch = get_object_or_404(Branch, id=branch_id)
    if not _has_branch_access(request.user, branch):
        return redirect("dashboard:home")
    floors = branch.floors.prefetch_related("places").order_by("sort_order", "id")
    from reservations.models import Booking
    active_bookings = (
        Booking.objects
        .filter(branch=branch, status__in=[Booking.Status.ACTIVE, Booking.Status.ARRIVED])
        .select_related("place__floor")
        .order_by("-started_at")
    )
    return render(request, "dashboard/tables.html", {
        "branch": branch,
        "floors": floors,
        "active_bookings": active_bookings,
    })


@require_POST
@login_required(login_url="dashboard:login")
def table_toggle_active(request, table_id):
    place = get_object_or_404(Place, id=table_id)
    if not _has_branch_access(request.user, place.floor.branch):
        return JsonResponse({"ok": False}, status=403)
    place.is_active = not place.is_active
    place.save(update_fields=["is_active"])
    return JsonResponse({"ok": True, "is_active": place.is_active})


@require_POST
@login_required(login_url="dashboard:login")
def booking_close(request, booking_id):
    from reservations.models import Booking as Bk
    from django.utils import timezone as tz
    bk = get_object_or_404(Bk, id=booking_id)
    if not _has_branch_access(request.user, bk.branch):
        return JsonResponse({"ok": False}, status=403)
    bk.status = Bk.Status.CLOSED
    bk.closed_at = tz.now()
    bk.save(update_fields=["status", "closed_at"])
    return JsonResponse({"ok": True})


@require_POST
@login_required(login_url="dashboard:login")
def floor_add(request, branch_id):
    branch = get_object_or_404(Branch, id=branch_id)
    if not _has_branch_access(request.user, branch):
        return JsonResponse({"ok": False}, status=403)
    name = request.POST.get("name", "").strip() or "Зал"
    floor = Floor.objects.create(branch=branch, name_ru=name)
    return JsonResponse({"ok": True, "id": floor.id, "name": floor.name_ru})


@require_POST
@login_required(login_url="dashboard:login")
def floor_delete(request, floor_id):
    floor = get_object_or_404(Floor, id=floor_id)
    if not _has_branch_access(request.user, floor.branch):
        return JsonResponse({"ok": False}, status=403)
    floor.delete()
    return JsonResponse({"ok": True})


@require_POST
@login_required(login_url="dashboard:login")
def floor_rename(request, floor_id):
    floor = get_object_or_404(Floor, id=floor_id)
    if not _has_branch_access(request.user, floor.branch):
        return JsonResponse({"ok": False}, status=403)
    name = request.POST.get("name", "").strip()
    if not name:
        return JsonResponse({"ok": False, "error": "Название не может быть пустым"})
    floor.name_ru = name
    floor.save(update_fields=["name_ru"])
    return JsonResponse({"ok": True, "name": floor.name_ru})


@require_POST
@login_required(login_url="dashboard:login")
def table_add(request, floor_id):
    floor = get_object_or_404(Floor, id=floor_id)
    if not _has_branch_access(request.user, floor.branch):
        return JsonResponse({"ok": False}, status=403)

    seats = max(1, int(request.POST.get("seats") or 2))
    bulk = request.POST.get("bulk") == "1"
    created = []

    if bulk:
        prefix = request.POST.get("prefix", "Стол").strip() or "Стол"
        start  = max(1, int(request.POST.get("start") or 1))
        count  = min(50, max(1, int(request.POST.get("count") or 1)))
        for i in range(start, start + count):
            p = Place.objects.create(floor=floor, title=f"{prefix} {i}", seats=seats)
            created.append({"id": p.id, "title": p.title, "seats": p.seats, "token": p.token})
    else:
        title = request.POST.get("title", "").strip()
        if not title:
            return JsonResponse({"ok": False, "error": "Название обязательно"})
        p = Place.objects.create(floor=floor, title=title, seats=seats)
        created.append({"id": p.id, "title": p.title, "seats": p.seats, "token": p.token})

    return JsonResponse({"ok": True, "tables": created})


@require_POST
@login_required(login_url="dashboard:login")
def table_delete(request, table_id):
    place = get_object_or_404(Place, id=table_id)
    if not _has_branch_access(request.user, place.floor.branch):
        return JsonResponse({"ok": False}, status=403)
    place.delete()
    return JsonResponse({"ok": True})


@require_POST
@login_required(login_url="dashboard:login")
def table_regen_token(request, table_id):
    if not request.user.is_superuser:
        return JsonResponse({"ok": False, "error": "Только суперпользователь"}, status=403)
    place = get_object_or_404(Place, id=table_id)
    new_token = request.POST.get("token", "").strip()
    if new_token:
        if Place.objects.filter(token=new_token).exclude(id=table_id).exists():
            return JsonResponse({"ok": False, "error": "Этот токен уже занят другим столом"})
        place.token = new_token
    else:
        place.token = _secrets.token_urlsafe(10)[:20]
    place.save(update_fields=["token"])
    return JsonResponse({"ok": True, "token": place.token})


# ══════════════════════════════════════════════════════════════════════════════
# POS — КАССА
# ══════════════════════════════════════════════════════════════════════════════

import json as _json
from orders.models import Order, OrderItem
from django.db.models import Prefetch as _Prefetch


@login_required(login_url="dashboard:login")
def pos(request, branch_id):
    branch = get_object_or_404(Branch, id=branch_id)
    if not (request.user.is_staff or request.user.is_superuser or _has_branch_access(request.user, branch)):
        return redirect("dashboard:home")

    categories = (
        BranchCategory.objects
        .filter(branch=branch, is_active=True)
        .select_related("category")
        .prefetch_related(
            _Prefetch(
                "items_in_category",
                queryset=(
                    BranchCategoryItem.objects
                    .select_related("branch_item__item")
                    .filter(branch_item__is_available=True)
                    .order_by("sort_order")
                ),
            )
        )
        .order_by("sort_order")
    )

    live_orders = (
        Order.objects
        .filter(branch=branch, status__in=[
            Order.Status.NEW, Order.Status.ACCEPTED,
            Order.Status.COOKING, Order.Status.READY,
        ])
        .prefetch_related("items__item")
        .order_by("-created_at")
    )

    # Столы и открытые заказы по столам
    try:
        from reservations.models import Place
        places_qs = list(
            Place.objects
            .filter(floor__branch=branch, is_active=True)
            .order_by("floor__name", "title")
        )
        open_table_order_map = {}
        for o in live_orders:
            tid = getattr(o, "table_place_id", None)
            if tid and tid not in open_table_order_map:
                open_table_order_map[tid] = o
        for place in places_qs:
            place.open_order = open_table_order_map.get(place.id)
    except Exception:
        places_qs = []

    return render(request, "dashboard/pos.html", {
        "branch": branch,
        "categories": categories,
        "live_orders": live_orders,
        "places": places_qs,
        "pos_delivery_fee": int(branch.delivery_fee) if branch.pos_delivery_fee_enabled else 0,
        "pos_delivery_fee_enabled": branch.pos_delivery_fee_enabled,
    })


@require_POST
@login_required(login_url="dashboard:login")
@transaction.atomic
def pos_order_create(request, branch_id):
    branch = get_object_or_404(Branch, id=branch_id)
    if not (request.user.is_staff or request.user.is_superuser or _has_branch_access(request.user, branch)):
        return JsonResponse({"ok": False}, status=403)

    try:
        data = _json.loads(request.body)
    except Exception:
        return JsonResponse({"ok": False, "error": "bad json"}, status=400)

    items_data      = data.get("items", [])
    order_type      = data.get("type", Order.Type.DINE_IN)
    payment_method  = data.get("payment", Order.PaymentMethod.CASH)
    customer_name   = (data.get("name") or "").strip()
    comment         = (data.get("comment") or "").strip()
    table_place_id  = data.get("table_place_id") or None
    promo_code_str  = (data.get("promo_code") or "").strip()

    if not items_data:
        return JsonResponse({"ok": False, "error": "Нет позиций"}, status=400)

    # Стол: если выбран — привязываем к заказу
    table_place = None
    if table_place_id and order_type == Order.Type.DINE_IN:
        from reservations.models import Place
        try:
            table_place = Place.objects.get(id=int(table_place_id), floor__branch=branch)
        except (Place.DoesNotExist, ValueError):
            pass

    _OPEN = [Order.Status.NEW, Order.Status.ACCEPTED, Order.Status.COOKING, Order.Status.READY]

    # Delivery fee: добавляем если тип=доставка и включено в настройках филиала
    applied_delivery_fee = Decimal("0")
    if (order_type == Order.Type.DELIVERY
            and branch.pos_delivery_fee_enabled
            and branch.delivery_fee > 0):
        applied_delivery_fee = branch.delivery_fee

    # Pre-calculate items and total
    total = Decimal("0")
    prepared_items = []
    for it in items_data:
        try:
            bi  = BranchItem.objects.select_related("item").get(
                id=int(it["bi_id"]), branch=branch, is_available=True
            )
            qty = max(1, int(it.get("qty", 1)))
            line = bi.price * qty
            prepared_items.append({"bi": bi, "qty": qty, "line": line})
            total += line
        except (BranchItem.DoesNotExist, ValueError, KeyError):
            continue

    with transaction.atomic():
        # If a table is selected, try to add to existing open order
        existing_order = None
        if table_place:
            existing_order = (
                Order.objects
                .filter(branch=branch, table_place=table_place, status__in=_OPEN)
                .select_for_update()
                .order_by("-created_at")
                .first()
            )

        if existing_order:
            order = existing_order
            new_oi_ids = []
            for pit in prepared_items:
                oi = OrderItem.objects.create(
                    order=order, item=pit["bi"].item,
                    qty=pit["qty"], price_snapshot=pit["bi"].price,
                    old_price_snapshot=pit["bi"].old_price if pit["bi"].is_on_promo else None,
                    line_total=pit["line"],
                )
                new_oi_ids.append(oi.id)
                bi = pit["bi"]
                if bi.stock is not None:
                    bi.stock = max(0, bi.stock - pit["qty"])
                    if bi.stock == 0:
                        bi.is_available = False
                    bi.save(update_fields=["stock", "is_available"])
            order.total_amount = order.total_amount + total
            order.save(update_fields=["total_amount"])
            open_table = True
        else:
            # ── Промокод ──
            from core.promo import resolve_promo, bump_promo_use
            promo, promo_discount, applied_delivery_fee, promo_label = resolve_promo(
                branch, promo_code_str, total, applied_delivery_fee,
                allow_free_delivery=(order_type == Order.Type.DELIVERY),
            )

            order = Order.objects.create(
                branch=branch,
                type=order_type,
                status=Order.Status.NEW,
                payment_method=payment_method,
                customer_name=customer_name,
                comment=comment,
                table_place=table_place,
                promo_code=(promo.code if promo else ""),
                promo_discount=promo_discount,
            )
            for pit in prepared_items:
                OrderItem.objects.create(
                    order=order, item=pit["bi"].item,
                    qty=pit["qty"], price_snapshot=pit["bi"].price,
                    old_price_snapshot=pit["bi"].old_price if pit["bi"].is_on_promo else None,
                    line_total=pit["line"],
                )
                bi = pit["bi"]
                if bi.stock is not None:
                    bi.stock = max(0, bi.stock - pit["qty"])
                    if bi.stock == 0:
                        bi.is_available = False
                    bi.save(update_fields=["stock", "is_available"])

            if promo:
                bump_promo_use(promo)

            order.delivery_fee   = applied_delivery_fee
            order.total_amount   = total - promo_discount + applied_delivery_fee

            # Заказ в зале со столом → оставляем ОТКРЫТЫМ
            # Остальные типы → сразу закрываем
            if table_place:
                order.save(update_fields=["total_amount", "delivery_fee", "promo_code", "promo_discount"])
                open_table = True
            else:
                order.status = Order.Status.CLOSED
                order.payment_status = Order.PaymentStatus.PAID
                order.save(update_fields=["total_amount", "delivery_fee", "status", "payment_status",
                                          "promo_code", "promo_discount"])
                open_table = False

    # Облачная печать — запускаем ПОСЛЕ коммита транзакции
    _order_id   = order.id
    _ex_order   = bool(existing_order)
    _new_oi_ids = list(new_oi_ids) if existing_order else None

    def _do_print():
        try:
            from printing.jobs import create_print_jobs
            from orders.models import Order as _Order
            _order = (
                _Order.objects
                .select_related("table_place__floor", "branch__restaurant")
                .get(id=_order_id)
            )
            if _ex_order:
                create_print_jobs(_order, new_item_ids=_new_oi_ids, new_cx_ids=[])
            else:
                create_print_jobs(_order)
        except Exception as e:
            import traceback
            print("PRINT create_print_jobs ERROR (pos):", e)
            traceback.print_exc()

    transaction.on_commit(_do_print)

    # Telegram уведомление
    # Для нового заказа — сигнал integrations/signals.py отправляет уведомление автоматически.
    # Здесь отправляем только дозаказ на стол (signal не срабатывает, т.к. Order не создаётся).
    if existing_order and table_place:
        try:
            from integrations.tasks import notify_extra_order
            new_items_tg = [
                {"name": pit["bi"].item.name_ru, "qty": pit["qty"]}
                for pit in prepared_items
            ]
            if new_items_tg:
                notify_extra_order.delay(order.id, new_items_tg)
        except Exception as e:
            print("TG notify_extra_order ERROR:", e)

    _promo_code = "" if existing_order else (order.promo_code or "")
    _promo_discount = Decimal("0") if existing_order else (order.promo_discount or Decimal("0"))
    return JsonResponse({
        "ok": True,
        "order_id": order.id,
        "total": str(total - _promo_discount + applied_delivery_fee),
        "items_total": str(total),
        "delivery_fee": str(applied_delivery_fee),
        "promo_code": _promo_code,
        "promo_discount": str(_promo_discount),
        "open_table": open_table,
        "table_place_id": table_place.id if table_place else None,
    })


@require_POST
@login_required(login_url="dashboard:login")
def pos_table_close(request, order_id):
    """Закрыть счёт стола — принять оплату. Закрывает ВСЕ открытые заказы на столе."""
    order = get_object_or_404(Order, id=order_id)
    if not (request.user.is_staff or request.user.is_superuser or _has_branch_access(request.user, order.branch)):
        return JsonResponse({"ok": False}, status=403)

    if order.status == Order.Status.CLOSED:
        return JsonResponse({"ok": False, "error": "Уже закрыт"})

    try:
        data = _json.loads(request.body)
    except Exception:
        data = {}

    payment_method = data.get("payment", order.payment_method)

    _OPEN = [Order.Status.NEW, Order.Status.ACCEPTED, Order.Status.COOKING, Order.Status.READY]

    with transaction.atomic():
        if order.table_place_id:
            all_open = list(
                Order.objects.select_for_update().filter(
                    branch=order.branch,
                    table_place_id=order.table_place_id,
                    status__in=_OPEN,
                )
            )
        else:
            all_open = [order]

        combined_total = Decimal("0")
        for o in all_open:
            o.payment_method = payment_method
            o.status = Order.Status.CLOSED
            o.payment_status = Order.PaymentStatus.PAID
            o.save(update_fields=["status", "payment_status", "payment_method"])
            combined_total += o.total_amount

        order.total_amount = combined_total
        order.save(update_fields=["total_amount"])

    # Печать чека покупателя
    try:
        from printing.jobs import create_receipt_job
        create_receipt_job(order)
    except Exception:
        pass

    return JsonResponse({
        "ok": True,
        "order_id": order.id,
        "total": str(combined_total),
    })


@login_required(login_url="dashboard:login")
def pos_table_order_json(request, place_id):
    """Получить открытый заказ по столу (для подгрузки в кассу)."""
    from reservations.models import Place
    place = get_object_or_404(Place, id=place_id)
    branch = place.floor.branch
    if not (request.user.is_staff or request.user.is_superuser or _has_branch_access(request.user, branch)):
        return JsonResponse({"ok": False}, status=403)

    order = (
        Order.objects
        .filter(
            branch=branch,
            table_place=place,
            status__in=[Order.Status.NEW, Order.Status.ACCEPTED,
                        Order.Status.COOKING, Order.Status.READY],
        )
        .prefetch_related("items__item")
        .order_by("-created_at")
        .first()
    )

    if not order:
        return JsonResponse({"ok": True, "order": None})

    items = [
        {
            "name": oi.item.name_ru,
            "qty": oi.qty,
            "price": str(oi.price_snapshot),
            "line_total": str(oi.line_total),
        }
        for oi in order.items.all()
    ]
    return JsonResponse({
        "ok": True,
        "order": {
            "id": order.id,
            "total": str(order.total_amount),
            "comment": order.comment,
            "items": items,
            "created_at": order.created_at.strftime("%H:%M"),
        },
    })


@require_POST
@login_required(login_url="dashboard:login")
def pos_order_status(request, order_id):
    order = get_object_or_404(Order, id=order_id)
    if not (request.user.is_staff or request.user.is_superuser or _has_branch_access(request.user, order.branch)):
        return JsonResponse({"ok": False}, status=403)

    prev_status = order.status
    new_status  = request.POST.get("status")
    new_payment = request.POST.get("payment_status")

    fields = []
    if new_status and new_status in Order.Status.values:
        # Restore stock when cancelling a closed POS order
        if new_status == Order.Status.CANCELLED and order.status == Order.Status.CLOSED:
            for oi in order.items.select_related("item").all():
                try:
                    bi = BranchItem.objects.get(branch=order.branch, item=oi.item)
                    if bi.stock is not None:
                        bi.stock += oi.qty
                        bi.is_available = True
                        bi.save(update_fields=["stock", "is_available"])
                except BranchItem.DoesNotExist:
                    pass
        order.status = new_status
        fields.append("status")
    if new_payment and new_payment in Order.PaymentStatus.values:
        order.payment_status = new_payment
        fields.append("payment_status")
    if fields:
        fields.append("updated_at")
        order.save(update_fields=fields)

    # При принятии входящего заказа (new → accepted) — отправить на кухонный принтер.
    # Заказ со стола по QR при выключённом print_on_accept уже напечатан при создании —
    # не дублируем. Доставка/самовывоз при создании не печатаются — печатаем здесь.
    if prev_status == Order.Status.NEW and new_status == Order.Status.ACCEPTED:
        already_printed = bool(order.table_place_id) and not order.branch.print_on_accept
        if not already_printed:
            try:
                from printing.jobs import create_print_jobs
                create_print_jobs(order)
            except Exception as e:
                import traceback
                print("PRINT create_print_jobs ERROR (accept):", e)
                traceback.print_exc()

    # При закрытии онлайн-заказа → печать итогового чека на кассовый принтер
    if new_status == Order.Status.CLOSED and prev_status != Order.Status.CLOSED:
        try:
            from printing.jobs import create_receipt_job
            create_receipt_job(order)
        except Exception as e:
            print("PRINT create_receipt_job ERROR (close):", e)

    return JsonResponse({
        "ok": True,
        "status": order.status,
        "payment_status": order.payment_status,
    })


@login_required(login_url="dashboard:login")
def pos_live_orders(request, branch_id):
    branch = get_object_or_404(Branch, id=branch_id)
    if not (request.user.is_staff or request.user.is_superuser or _has_branch_access(request.user, branch)):
        return JsonResponse({"ok": False}, status=403)

    orders = (
        Order.objects
        .filter(branch=branch, status__in=[
            Order.Status.NEW, Order.Status.ACCEPTED,
            Order.Status.COOKING, Order.Status.READY,
        ])
        .prefetch_related("items__item", "constructor_items")
        .order_by("-created_at")
    )

    result = []
    for o in orders:
        items = [
            {"name": oi.item.name_ru, "qty": oi.qty, "line": str(oi.line_total)}
            for oi in o.items.all()
        ]
        for ci in o.constructor_items.all():
            ing_parts = []
            for sel in (ci.ingredients_snapshot or []):
                from collections import Counter
                _counts = Counter()
                for _i in sel.get("ings", []):
                    if _i.get("name"):
                        _counts[_i["name"]] += int(_i.get("qty", 1))
                ing_names = ", ".join(f"{n} ×{c}" if c > 1 else n for n, c in _counts.items())
                ing_parts.append(f"{sel['gname']}: {ing_names}")
            detail = " · ".join(ing_parts)
            items.append({
                "name": f"🧩 {ci.constructor_name_snapshot}" + (f" ({detail})" if detail else ""),
                "qty":  ci.qty,
                "line": str(ci.line_total),
            })
        result.append({
            "id":             o.id,
            "type":           o.type,
            "type_label":     o.get_type_display(),
            "status":         o.status,
            "status_label":   o.get_status_display(),
            "customer":       o.customer_name,
            "phone":          o.customer_phone,
            "address":        o.delivery_address,
            "total":          str(o.total_amount),
            "payment":        o.payment_method,
            "payment_status": o.payment_status,
            "comment":        o.comment,
            "created":        o.created_at.strftime("%H:%M"),
            "items": items,
        })

    return JsonResponse({"ok": True, "orders": result})


@login_required(login_url="dashboard:login")
def pos_receipt(request, order_id):
    order = get_object_or_404(
        Order.objects
        .prefetch_related("items__item", "constructor_items")
        .select_related("branch__restaurant", "table_place"),
        id=order_id,
    )
    if not (request.user.is_staff or request.user.is_superuser or _has_branch_access(request.user, order.branch)):
        return redirect("dashboard:home")
    return render(request, "dashboard/receipt.html", {"order": order})


# ── POS Inventory ────────────────────────────────────────────────────────────

@login_required(login_url="dashboard:login")
def pos_inventory(request, branch_id):
    branch = get_object_or_404(Branch, id=branch_id)
    if not (request.user.is_staff or request.user.is_superuser or _has_branch_access(request.user, branch)):
        return redirect("dashboard:home")

    if request.method == "POST":
        # AJAX bulk update: [{bi_id, stock}, ...]
        import json as _json2
        try:
            updates = _json2.loads(request.body)
        except Exception:
            return JsonResponse({"ok": False, "error": "bad json"}, status=400)
        for u in updates:
            try:
                bi = BranchItem.objects.get(id=int(u["bi_id"]), branch=branch)
                raw = u.get("stock")
                if raw == "" or raw is None:
                    bi.stock = None         # unlimited
                    bi.is_available = True
                else:
                    val = int(raw)
                    bi.stock = max(0, val)
                    bi.is_available = (bi.stock > 0)
                bi.save(update_fields=["stock", "is_available"])
            except Exception:
                continue
        return JsonResponse({"ok": True})

    # GET — load all branch items grouped by category
    categories = (
        BranchCategory.objects
        .filter(branch=branch, is_active=True)
        .select_related("category")
        .prefetch_related(
            _Prefetch(
                "items_in_category",
                queryset=BranchCategoryItem.objects.select_related(
                    "branch_item__item"
                ).order_by("sort_order"),
            )
        )
        .order_by("sort_order")
    )
    return render(request, "dashboard/pos_inventory.html", {
        "branch": branch,
        "categories": categories,
    })


# ── POS Report ───────────────────────────────────────────────────────────────

@login_required(login_url="dashboard:login")
def pos_report(request, branch_id):
    from datetime import date as _date, datetime as _dt
    from django.db.models import Sum as _Sum, Q as _Q
    from django.db.models.functions import TruncDate
    from orders.models import OrderItem as _OI, ConstructorOrderItem

    branch = get_object_or_404(Branch, id=branch_id)
    if not (request.user.is_staff or request.user.is_superuser or _has_branch_access(request.user, branch)):
        return redirect("dashboard:home")

    today = _date.today()
    date_from_str = request.GET.get("from", str(today))
    date_to_str   = request.GET.get("to",   str(today))
    try:
        date_from = _dt.strptime(date_from_str, "%Y-%m-%d").date()
        date_to   = _dt.strptime(date_to_str,   "%Y-%m-%d").date()
    except ValueError:
        date_from = date_to = today
    if date_from > date_to:
        date_from, date_to = date_to, date_from

    base_qs = Order.objects.filter(
        branch=branch,
        created_at__date__gte=date_from,
        created_at__date__lte=date_to,
    )

    closed    = base_qs.filter(status=Order.Status.CLOSED)
    cancelled = base_qs.filter(status=Order.Status.CANCELLED)

    # ── Выручка = сумма позиций (line_total), без доставки ──
    # Используем сумму line_total из OrderItem + ConstructorOrderItem —
    # это единственный надёжный способ: delivery_fee в старых заказах мог
    # не сохраняться, но line_total всегда считается только по блюдам.
    def _revenue(order_qs):
        ids = order_qs.values_list("id", flat=True)
        item_rev = _OI.objects.filter(order_id__in=ids).aggregate(s=_Sum("line_total"))["s"] or Decimal("0")
        cx_rev   = ConstructorOrderItem.objects.filter(order_id__in=ids).aggregate(s=_Sum("line_total"))["s"] or Decimal("0")
        return item_rev + cx_rev

    # выручка по позициям минус скидки по промокодам (order.promo_discount)
    promo_codes_sum = closed.aggregate(s=_Sum("promo_discount"))["s"] or Decimal("0")
    promo_codes_cnt = closed.exclude(promo_code="").count()
    total_revenue   = _revenue(closed) - promo_codes_sum
    total_orders    = closed.count()
    cancelled_count = cancelled.count()
    cancelled_sum   = _revenue(cancelled)

    # ── Скидки по акциям (BranchItem.old_price на момент заказа) ──
    from django.db.models import ExpressionWrapper as _EW, F as _F, DecimalField as _DecF
    promo_lines = (
        _OI.objects
        .filter(order__in=closed, old_price_snapshot__isnull=False, old_price_snapshot__gt=_F("price_snapshot"))
        .annotate(discount_line=_EW(
            (_F("old_price_snapshot") - _F("price_snapshot")) * _F("qty"),
            output_field=_DecF(max_digits=10, decimal_places=2),
        ))
    )
    promo_discount_sum   = promo_lines.aggregate(s=_Sum("discount_line"))["s"] or Decimal("0")
    promo_items_count    = promo_lines.aggregate(s=_Sum("qty"))["s"] or 0

    # Сумма доставки по закрытым доставочным заказам
    total_delivery_fees = (
        closed.filter(type=Order.Type.DELIVERY)
        .aggregate(s=_Sum("delivery_fee"))["s"] or Decimal("0")
    )

    # ── Онлайн vs Офлайн ──
    online_qs  = closed.filter(
        _Q(table_place__isnull=False) |
        _Q(type__in=[Order.Type.DELIVERY, Order.Type.PICKUP])
    )
    offline_qs = closed.filter(
        table_place__isnull=True,
        type=Order.Type.DINE_IN,
    )
    online_revenue  = _revenue(online_qs)
    offline_revenue = _revenue(offline_qs)
    online_count    = online_qs.count()
    offline_count   = offline_qs.count()

    # ── По способу оплаты ──
    pay_cash   = _revenue(closed.filter(payment_method="cash"))
    pay_online = _revenue(closed.filter(payment_method="online"))

    # ── Топ блюд ──
    regular_items = (
        _OI.objects
        .filter(order__in=closed)
        .values("item__name_ru")
        .annotate(total_qty=_Sum("qty"), total_rev=_Sum("line_total"))
    )
    cx_items_qs = (
        ConstructorOrderItem.objects
        .filter(order__in=closed)
        .values("constructor_name_snapshot")
        .annotate(total_qty=_Sum("qty"), total_rev=_Sum("line_total"))
    )
    top_items = []
    for r in regular_items:
        top_items.append({"name": r["item__name_ru"], "qty": r["total_qty"], "rev": r["total_rev"] or Decimal("0")})
    for r in cx_items_qs:
        name = (r["constructor_name_snapshot"] or "Собери сам") + " 🧩"
        top_items.append({"name": name, "qty": r["total_qty"], "rev": r["total_rev"] or Decimal("0")})
    top_items.sort(key=lambda x: x["rev"], reverse=True)
    top_items = top_items[:20]

    # ── Разбивка по дням (через item line_total) ──
    # Собираем line_total по order_id для закрытых заказов
    closed_ids = list(closed.values_list("id", flat=True))

    item_rev_map = {
        r["order_id"]: r["s"]
        for r in _OI.objects.filter(order_id__in=closed_ids)
            .values("order_id").annotate(s=_Sum("line_total"))
    }
    cx_rev_map = {
        r["order_id"]: r["s"]
        for r in ConstructorOrderItem.objects.filter(order_id__in=closed_ids)
            .values("order_id").annotate(s=_Sum("line_total"))
    }

    order_days = (
        closed
        .annotate(day=TruncDate("created_at"))
        .values("id", "day")
        .order_by("day")
    )

    daily_agg = {}
    for row in order_days:
        day = row["day"]
        rev = (item_rev_map.get(row["id"]) or Decimal("0")) + (cx_rev_map.get(row["id"]) or Decimal("0"))
        if day not in daily_agg:
            daily_agg[day] = {"cnt": 0, "rev": Decimal("0")}
        daily_agg[day]["cnt"] += 1
        daily_agg[day]["rev"] += rev

    cancelled_daily = {
        row["day"]: row["cnt"]
        for row in cancelled
            .annotate(day=TruncDate("created_at"))
            .values("day").annotate(cnt=Count("id"))
    }
    online_daily = {
        row["day"]: row["cnt"]
        for row in online_qs
            .annotate(day=TruncDate("created_at"))
            .values("day").annotate(cnt=Count("id"))
    }
    offline_daily = {
        row["day"]: row["cnt"]
        for row in offline_qs
            .annotate(day=TruncDate("created_at"))
            .values("day").annotate(cnt=Count("id"))
    }

    daily = [
        {
            "day":       day,
            "cnt":       vals["cnt"],
            "rev":       vals["rev"],
            "cancelled": cancelled_daily.get(day, 0),
            "online":    online_daily.get(day, 0),
            "offline":   offline_daily.get(day, 0),
        }
        for day, vals in sorted(daily_agg.items())
    ]

    return render(request, "dashboard/pos_report.html", {
        "branch":           branch,
        "date_from":        date_from,
        "date_to":          date_to,
        "total_revenue":    total_revenue,
        "total_orders":     total_orders,
        "cancelled_count":  cancelled_count,
        "cancelled_sum":    cancelled_sum,
        "online_revenue":   online_revenue,
        "offline_revenue":  offline_revenue,
        "online_count":     online_count,
        "offline_count":    offline_count,
        "pay_cash":              pay_cash,
        "pay_online_amt":        pay_online,
        "top_items":             top_items,
        "daily":                 daily,
        "total_delivery_fees":   total_delivery_fees,
        "promo_discount_sum":    promo_discount_sum,
        "promo_items_count":     promo_items_count,
        "promo_codes_sum":       promo_codes_sum,
        "promo_codes_cnt":       promo_codes_cnt,
    })


# ── POS History ───────────────────────────────────────────────────────────────

@login_required(login_url="dashboard:login")
def pos_history(request, branch_id):
    from datetime import date as _date, datetime as _dt
    branch = get_object_or_404(Branch, id=branch_id)
    if not (request.user.is_staff or request.user.is_superuser or _has_branch_access(request.user, branch)):
        return redirect("dashboard:home")

    today = _date.today()
    date_str = request.GET.get("date", str(today))
    try:
        sel_date = _dt.strptime(date_str, "%Y-%m-%d").date()
    except ValueError:
        sel_date = today

    from django.db.models import ExpressionWrapper, F, DecimalField as _Dec
    orders = (
        Order.objects
        .filter(branch=branch, created_at__date=sel_date)
        .prefetch_related("items__item", "constructor_items")
        .annotate(net_total=ExpressionWrapper(
            F("total_amount") - F("delivery_fee"),
            output_field=_Dec(max_digits=10, decimal_places=2),
        ))
        .order_by("-created_at")
    )

    return render(request, "dashboard/pos_history.html", {
        "branch":    branch,
        "orders":    orders,
        "sel_date":  sel_date,
        "today":     today,
    })


@require_POST
@login_required(login_url="dashboard:login")
def pos_order_cancel(request, order_id):
    order = get_object_or_404(Order, id=order_id)
    if not (request.user.is_staff or request.user.is_superuser or _has_branch_access(request.user, order.branch)):
        return JsonResponse({"ok": False}, status=403)

    if order.status == Order.Status.CANCELLED:
        return JsonResponse({"ok": False, "error": "Уже отменён"})

    # Restore stock for closed POS orders
    if order.status == Order.Status.CLOSED:
        for oi in order.items.select_related("item").all():
            try:
                bi = BranchItem.objects.get(branch=order.branch, item=oi.item)
                if bi.stock is not None:
                    bi.stock += oi.qty
                    bi.is_available = True
                    bi.save(update_fields=["stock", "is_available"])
            except BranchItem.DoesNotExist:
                pass

    order.status = Order.Status.CANCELLED
    order.save(update_fields=["status", "updated_at"])

    return JsonResponse({"ok": True})


# ── КОНСТРУКТОР БЛЮД ──────────────────────────────────────────────────────────

@login_required(login_url="dashboard:login")
def constructor_list(request, branch_id):
    from catalog.models import BranchItem
    branch = get_object_or_404(Branch, id=branch_id)
    if not _has_branch_access(request.user, branch):
        return redirect("dashboard:home")
    constructors = branch.dish_constructors.prefetch_related(
        "groups__ingredients__branch_item__item",
        "groups__ingredients__warehouse_ingredient",
    ).order_by("sort_order", "id")
    branch_items = (
        BranchItem.objects.select_related("item")
        .filter(branch=branch, is_available=True)
        .order_by("item__name_ru")
    )
    from techcards.models import Ingredient as _Ingredient
    warehouse_ingredients = (
        _Ingredient.objects
        .filter(restaurant=branch.restaurant, is_active=True)
        .order_by("name_ru")
    )
    return render(request, "dashboard/constructor.html", {
        "branch": branch,
        "constructors": constructors,
        "branch_items": branch_items,
        "warehouse_ingredients": warehouse_ingredients,
    })


@require_POST
@login_required(login_url="dashboard:login")
def constructor_add(request, branch_id):
    branch = get_object_or_404(Branch, id=branch_id)
    if not _has_branch_access(request.user, branch):
        return JsonResponse({"ok": False}, status=403)
    name       = request.POST.get("name", "").strip()
    base_price = request.POST.get("base_price", "0").strip() or "0"
    desc       = request.POST.get("description", "").strip()
    if not name:
        return JsonResponse({"ok": False, "error": "Введите название"})
    from decimal import InvalidOperation
    try:
        bp = Decimal(base_price)
    except InvalidOperation:
        bp = Decimal("0")
    cx = DishConstructor.objects.create(branch=branch, name=name, base_price=bp, description=desc)
    photo = request.FILES.get("photo")
    if photo:
        cx.photo = photo
        cx.save()
    return JsonResponse({"ok": True, "id": cx.id, "name": cx.name, "base_price": str(cx.base_price),
                         "photo_url": cx.photo.url if cx.photo else ""})


@require_POST
@login_required(login_url="dashboard:login")
def constructor_photo_update(request, cx_id):
    cx = get_object_or_404(DishConstructor, id=cx_id)
    if not _has_branch_access(request.user, cx.branch):
        return JsonResponse({"ok": False}, status=403)
    photo = request.FILES.get("photo")
    if not photo:
        return JsonResponse({"ok": False, "error": "Нет файла"})
    cx.photo = photo
    cx.save()
    return JsonResponse({"ok": True, "photo_url": cx.photo.url})


@require_POST
@login_required(login_url="dashboard:login")
def constructor_delete(request, cx_id):
    cx = get_object_or_404(DishConstructor, id=cx_id)
    if not _has_branch_access(request.user, cx.branch):
        return JsonResponse({"ok": False}, status=403)
    cx.delete()
    return JsonResponse({"ok": True})


@require_POST
@login_required(login_url="dashboard:login")
def constructor_toggle(request, cx_id):
    cx = get_object_or_404(DishConstructor, id=cx_id)
    if not _has_branch_access(request.user, cx.branch):
        return JsonResponse({"ok": False}, status=403)
    cx.is_active = not cx.is_active
    cx.save(update_fields=["is_active"])
    return JsonResponse({"ok": True, "is_active": cx.is_active})


@require_POST
@login_required(login_url="dashboard:login")
def constructor_group_add(request, cx_id):
    cx = get_object_or_404(DishConstructor, id=cx_id)
    if not _has_branch_access(request.user, cx.branch):
        return JsonResponse({"ok": False}, status=403)
    name       = request.POST.get("name", "").strip()
    min_select = int(request.POST.get("min_select", 1) or 1)
    max_select = int(request.POST.get("max_select", 1) or 1)
    if not name:
        return JsonResponse({"ok": False, "error": "Введите название группы"})
    g = ConstructorGroup.objects.create(constructor=cx, name=name, min_select=min_select, max_select=max_select)
    return JsonResponse({"ok": True, "id": g.id, "name": g.name, "min_select": g.min_select, "max_select": g.max_select})


@require_POST
@login_required(login_url="dashboard:login")
def constructor_group_delete(request, group_id):
    g = get_object_or_404(ConstructorGroup, id=group_id)
    if not _has_branch_access(request.user, g.constructor.branch):
        return JsonResponse({"ok": False}, status=403)
    g.delete()
    return JsonResponse({"ok": True})


@require_POST
@login_required(login_url="dashboard:login")
def constructor_ingredient_add(request, group_id):
    g = get_object_or_404(ConstructorGroup, id=group_id)
    if not _has_branch_access(request.user, g.constructor.branch):
        return JsonResponse({"ok": False}, status=403)
    name  = request.POST.get("name", "").strip()
    desc  = request.POST.get("description", "").strip()
    price_raw = request.POST.get("price", "0").strip() or "0"
    if not name:
        return JsonResponse({"ok": False, "error": "Введите название"})
    from decimal import InvalidOperation
    try:
        price = Decimal(price_raw)
    except InvalidOperation:
        price = Decimal("0")
    photo = request.FILES.get("photo")
    ing = ConstructorIngredient(group=g, name=name, description=desc, price=price)
    if photo:
        ing.photo = photo
    ing.save()
    return JsonResponse({"ok": True, "id": ing.id, "name": ing.name, "description": ing.description,
                         "price": str(ing.price), "photo_url": ing.photo.url if ing.photo else ""})


@require_POST
@login_required(login_url="dashboard:login")
def constructor_ingredient_from_menu(request, group_id):
    """Добавить позицию в категорию конструктора из существующего блюда меню."""
    from catalog.models import BranchItem
    g = get_object_or_404(ConstructorGroup, id=group_id)
    if not _has_branch_access(request.user, g.constructor.branch):
        return JsonResponse({"ok": False}, status=403)
    bi_id = request.POST.get("branch_item_id")
    bi = get_object_or_404(BranchItem, id=bi_id, branch=g.constructor.branch)
    # Не добавлять дублей
    if ConstructorIngredient.objects.filter(group=g, branch_item=bi).exists():
        return JsonResponse({"ok": False, "error": "Уже добавлено"})
    ing = ConstructorIngredient.objects.create(group=g, branch_item=bi)
    return JsonResponse({
        "ok": True,
        "id": ing.id,
        "name": ing.display_name,
        "description": ing.display_description,
        "price": str(ing.display_price),
        "photo_url": ing.display_photo_url,
    })


@require_POST
@login_required(login_url="dashboard:login")
def constructor_ingredient_delete(request, ing_id):
    ing = get_object_or_404(ConstructorIngredient, id=ing_id)
    if not _has_branch_access(request.user, ing.group.constructor.branch):
        return JsonResponse({"ok": False}, status=403)
    ing.delete()
    return JsonResponse({"ok": True})


@require_POST
@login_required(login_url="dashboard:login")
def constructor_ingredient_update(request, ing_id):
    """Обновить цену (и имя, если ручной) ингредиента."""
    ing = get_object_or_404(ConstructorIngredient, id=ing_id)
    if not _has_branch_access(request.user, ing.group.constructor.branch):
        return JsonResponse({"ok": False}, status=403)
    price_raw = request.POST.get("price", "").strip()
    if price_raw != "":
        try:
            ing.price = Decimal(price_raw)
        except Exception:
            return JsonResponse({"ok": False, "error": "Неверная цена"})
    if not ing.branch_item_id:
        name = request.POST.get("name", "").strip()
        if name:
            ing.name = name
    ing.save()
    return JsonResponse({"ok": True, "price": str(ing.display_price), "name": ing.display_name})


@require_POST
@login_required(login_url="dashboard:login")
def constructor_ingredient_stock_update(request, ing_id):
    """Привязать позицию конструктора к ингредиенту склада."""
    ing = get_object_or_404(ConstructorIngredient, id=ing_id)
    if not _has_branch_access(request.user, ing.group.constructor.branch):
        return JsonResponse({"ok": False}, status=403)
    from techcards.models import Ingredient as _Ingredient
    wi_id = request.POST.get("warehouse_ingredient_id", "").strip()
    qty_raw = request.POST.get("write_off_qty", "1").strip() or "1"
    if wi_id:
        wi = get_object_or_404(_Ingredient, id=wi_id,
                                restaurant=ing.group.constructor.branch.restaurant)
        ing.warehouse_ingredient = wi
    else:
        ing.warehouse_ingredient = None
    try:
        ing.write_off_qty = Decimal(qty_raw)
    except Exception:
        ing.write_off_qty = Decimal("1")
    ing.save(update_fields=["warehouse_ingredient", "write_off_qty"])
    wi_name = ing.warehouse_ingredient.name_ru if ing.warehouse_ingredient else ""
    return JsonResponse({"ok": True, "wi_name": wi_name,
                         "write_off_qty": str(ing.write_off_qty)})


@require_POST
@login_required(login_url="dashboard:login")
def constructor_group_update(request, group_id):
    """Обновить min/max группы."""
    g = get_object_or_404(ConstructorGroup, id=group_id)
    if not _has_branch_access(request.user, g.constructor.branch):
        return JsonResponse({"ok": False}, status=403)
    try:
        min_s = int(request.POST.get("min_select", g.min_select))
        max_s = int(request.POST.get("max_select", g.max_select))
    except (ValueError, TypeError):
        return JsonResponse({"ok": False, "error": "Неверные значения"})
    g.min_select = min_s
    g.max_select = max_s
    g.save()
    return JsonResponse({"ok": True, "min_select": g.min_select, "max_select": g.max_select})


# ── ОПРОС ЗАВЕДЕНИЙ: анализ ответов (только staff/superuser) ──────────────────

_SURVEY_STOPWORDS = set(
    "и в на не что как с по для это а но то же из у к о об от до или если когда "
    "все всё его их она он вы мы я бы ли уже очень просто можно нужно надо есть "
    "быть было были будет такой такие таких этого этом этой эти эту него нее "
    "себя свои свой своих тем при без ещё еще также только более менее чем "
    "чтобы который которые которых наш наша наши вам нам них им мне тебя тебе "
    "там тут здесь сейчас пока какой какая какие ну да нет каждый всего всех "
    "этих этим эта".split()
)


def _survey_top_words(responses, field, limit=8):
    import re
    from collections import Counter
    freq = Counter()
    for r in responses:
        text = (getattr(r, field) or "").lower()
        words = re.findall(r"[a-zа-яё0-9-]+", text)
        for w in words:
            if len(w) > 2 and w not in _SURVEY_STOPWORDS:
                freq[w] += 1
    return freq.most_common(limit)


@login_required(login_url="dashboard:login")
def survey_results(request):
    from public_site.models import SurveyResponse

    if not (request.user.is_staff or request.user.is_superuser):
        messages.error(request, "Недостаточно прав для просмотра опроса.")
        return redirect("dashboard:home")

    responses = list(SurveyResponse.objects.all())
    n = len(responses)
    avg_score = round(sum(r.score for r in responses) / n, 1) if n else 0

    histogram = [sum(1 for r in responses if r.score == i) for i in range(1, 11)]
    max_count = max(histogram) or 1

    skeptics   = sum(1 for r in responses if r.score <= 6)
    interested = sum(1 for r in responses if 7 <= r.score <= 8)
    ready      = sum(1 for r in responses if r.score >= 9)

    words_q1 = _survey_top_words(responses, "q1")
    words_q2 = _survey_top_words(responses, "q2")

    return render(request, "dashboard/survey_results.html", {
        "responses": responses,
        "n": n,
        "avg_score": avg_score,
        "histogram": list(zip(range(1, 11), histogram)),
        "max_count": max_count,
        "skeptics": skeptics,
        "interested": interested,
        "ready": ready,
        "words_q1": words_q1,
        "words_q2": words_q2,
    })
