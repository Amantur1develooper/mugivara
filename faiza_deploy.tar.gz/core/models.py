from django.db import models
from django.conf import settings
from django.utils import timezone
import os
from io import BytesIO
from django.core.files.base import ContentFile
from PIL import Image


class TimeStampedModel(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    class Meta:
        abstract = True


class PlaceCategory(models.Model):
    """Категория платформы (Еда, Отели, Магазины …) — сердце безрелизности."""
    slug        = models.SlugField(max_length=80, unique=True)
    name_ru     = models.CharField(max_length=100)
    name_ky     = models.CharField(max_length=100, blank=True, default="")
    name_en     = models.CharField(max_length=100, blank=True, default="")
    subtitle_ru = models.CharField(max_length=200, blank=True, default="")
    subtitle_ky = models.CharField(max_length=200, blank=True, default="")
    subtitle_en = models.CharField(max_length=200, blank=True, default="")
    icon        = models.CharField("Иконка (эмодзи или URL)", max_length=200, blank=True, default="")
    sort_order  = models.PositiveSmallIntegerField(default=0)
    is_active   = models.BooleanField(default=True)

    # Флаги поведения — приложение строит UI по ним
    supports_catalog  = models.BooleanField("Есть каталог (меню/товары)", default=True)
    supports_ordering = models.BooleanField("Есть заказ", default=True)
    supports_booking  = models.BooleanField("Есть бронирование", default=False)

    item_noun_ru = models.CharField("Позиции (рус)", max_length=50, default="Блюда")
    item_noun_ky = models.CharField("Позиции (кыр)", max_length=50, blank=True, default="")
    item_noun_en = models.CharField("Позиции (eng)", max_length=50, blank=True, default="")

    class Meta:
        ordering = ["sort_order", "id"]
        verbose_name = "Категория платформы"
        verbose_name_plural = "Категории платформы"

    def __str__(self):
        return self.name_ru


class Restaurant(TimeStampedModel):
    place_category = models.ForeignKey(
        PlaceCategory, null=True, blank=True,
        on_delete=models.SET_NULL, related_name="places",
        verbose_name="Категория платформы",
    )
    cover = models.ImageField(
        "Обложка (для списка заведений)", upload_to="restaurants/covers/",
        blank=True, null=True,
    )
    name_ru = models.CharField(max_length=200)
    name_ky = models.CharField(max_length=200, blank=True, default="")
    name_en = models.CharField(max_length=200, blank=True, default="")
    slug = models.SlugField(max_length=220, unique=True)
    logo = models.ImageField(upload_to="restaurants/logos/", blank=True, null=True)
    is_active = models.BooleanField(default=True)
    rating = models.DecimalField("Рейтинг", max_digits=3, decimal_places=1, default=0.0)
    about_ru = models.TextField(blank=True, default="")
    about_ky = models.TextField(blank=True, default="")
    about_en = models.TextField(blank=True, default="")
    external_url = models.URLField(
        "Ссылка на сайт / приложение",
        blank=True, default="",
        help_text="Если заполнено — кнопка «Перейти к заказу» будет вести на этот сайт"
    )
    phone        = models.CharField("Телефон", max_length=60, blank=True, default="")
    whatsapp     = models.CharField("WhatsApp (номер)", max_length=60, blank=True, default="",
                                    help_text="Только цифры со знаком +, напр. +996700123456")
    instagram    = models.URLField("Instagram", blank=True, default="")
    telegram     = models.CharField("Telegram (@username или ссылка)", max_length=120, blank=True, default="")
    map_url      = models.URLField("Ссылка на карту (2GIS / Google Maps)", blank=True, default="")
    tiktok       = models.URLField("TikTok", blank=True, default="")

    class Meta:
        verbose_name = "Ресторан"
        verbose_name_plural = "Рестораны"
        indexes = [
            models.Index(fields=["is_active", "-rating"], name="restaurant_active_rating_idx"),
            models.Index(fields=["slug"], name="restaurant_slug_idx"),
        ]
        
    def __str__(self):
        return self.name_ru
    

class Branch(TimeStampedModel):
    restaurant = models.ForeignKey(Restaurant, on_delete=models.CASCADE, related_name="branches")
    
    name_ru = models.CharField(max_length=200)
    name_ky = models.CharField(max_length=200, blank=True, default="")
    name_en = models.CharField(max_length=200, blank=True, default="")
    map_url = models.URLField("Ссылка на карту", blank=True, default="")
    address = models.CharField(max_length=300, blank=True)
    phone = models.CharField(max_length=50, blank=True)
    is_active = models.BooleanField(default=True)
    
    delivery_enabled = models.BooleanField(default=False)
    min_order_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    delivery_fee = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    pos_delivery_fee_enabled = models.BooleanField(
        "Добавлять стоимость доставки в кассе", default=True,
        help_text="Автоматически добавлять delivery_fee к заказу при оформлении доставки через кассу"
    )
    free_delivery_from = models.DecimalField(
        "Бесплатная доставка от (сом)", max_digits=10, decimal_places=2,
        default=0, help_text="0 = не действует"
    )
    
    is_open_24h = models.BooleanField(default=False)
    open_time  = models.TimeField(null=True, blank=True)
    close_time = models.TimeField(null=True, blank=True)
    work_days  = models.CharField("Рабочие дни", max_length=20, blank=True, default="")
    cover_photo = models.ImageField(upload_to="branches/covers/", blank=True, null=True)
    promo_photo = models.ImageField(
        "Фото для акции (фон карусели)",
        upload_to="branches/promo/", blank=True, null=True,
    )
    external_url = models.URLField(
        "Внешний сайт / приложение",
        blank=True, default="",
        help_text="Если заполнено — кнопка «Открыть меню» будет вести на этот адрес"
    )

    pay_cash_enabled   = models.BooleanField("Наличные (касса)", default=True)
    pay_online_enabled = models.BooleanField("Онлайн / карта (касса)", default=True)

    print_on_accept = models.BooleanField(
        "Печать только после подтверждения кассиром",
        default=False,
        help_text=(
            "Если включено — кухонный чек печатается не сразу при заказе через QR, "
            "а только после того как кассир/официант нажмёт «Принять заказ» в панели столов."
        ),
    )
    lat = models.DecimalField("Широта",  max_digits=10, decimal_places=7, null=True, blank=True)
    lon = models.DecimalField("Долгота", max_digits=10, decimal_places=7, null=True, blank=True)

    # ── Индивидуальный дизайн страницы меню (доп. услуга) ───────────────────
    template_slug = models.SlugField(
        "Индивидуальный дизайн", max_length=60, blank=True, default="",
        help_text=(
            "Код темы оформления. Пусто — стандартная страница меню. "
            "Если заполнено, меню рендерится шаблоном templates/custom/<код>/menu.html, "
            "а статика берётся из static/custom/<код>/. Корзина, заказы, цены "
            "и кабинет остаются общими."
        ),
    )

    def save(self, *args, **kwargs):
        self.photo_compression = None
        if self.promo_photo and hasattr(self.promo_photo, 'file'):
            try:
                original_size = self.promo_photo.file.seek(0, 2) or self.promo_photo.file.tell()
                self.promo_photo.file.seek(0)
                img = Image.open(self.promo_photo).convert("RGB")
                orig_w, orig_h = img.size
                img.thumbnail((1200, 600), Image.LANCZOS)
                new_w, new_h = img.size
                buf = BytesIO()
                img.save(buf, format="WEBP", quality=85, method=6)
                compressed_size = buf.tell()
                buf.seek(0)
                name = os.path.splitext(self.promo_photo.name)[0] + ".webp"
                self.promo_photo.save(name, ContentFile(buf.read()), save=False)
                self.photo_compression = {
                    "before_kb": round(original_size / 1024, 1),
                    "after_kb":  round(compressed_size / 1024, 1),
                    "saved_pct": round((1 - compressed_size / original_size) * 100) if original_size else 0,
                    "orig_size": f"{orig_w}×{orig_h}",
                    "new_size":  f"{new_w}×{new_h}",
                }
            except Exception:
                pass
        super().save(*args, **kwargs)

    class Meta:
        verbose_name = "Филиал"
        verbose_name_plural = "Филиалы"
        indexes = [
            models.Index(fields=["restaurant", "is_active"], name="branch_restaurant_active_idx"),
        ]
        
    def __str__(self):
        return f"{self.restaurant.name_ru} — {self.name_ru}"
    
    def is_open_now(self) -> bool:
        if not self.is_active:
            return False
        if self.is_open_24h:
            return True
        now = timezone.localtime()
        if self.work_days:
            allowed = {int(d) for d in self.work_days.split(",") if d.strip().isdigit()}
            if now.weekday() not in allowed:
                return False
        if not self.open_time or not self.close_time:
            return False
        t = now.time()
        if self.open_time < self.close_time:
            return self.open_time <= t < self.close_time
        return t >= self.open_time or t < self.close_time

class PromoCode(TimeStampedModel):
    class DiscountType(models.TextChoices):
        FREE_DELIVERY = "free_delivery", "Бесплатная доставка"
        PERCENT       = "percent",       "Скидка в процентах"
        FIXED         = "fixed",         "Скидка фиксированной суммой"

    branch         = models.ForeignKey(Branch, on_delete=models.CASCADE, related_name="promo_codes")
    code           = models.CharField("Промокод", max_length=50)
    discount_type  = models.CharField("Тип скидки", max_length=20, choices=DiscountType.choices)
    discount_value = models.DecimalField(
        "Размер скидки", max_digits=10, decimal_places=2, default=0,
        help_text="Для % — число (10 = 10%). Для суммы — сом (500). Для бесплатной доставки — 0.",
    )
    valid_until    = models.DateField("Действует до", null=True, blank=True)
    is_active      = models.BooleanField("Активен", default=True)
    max_uses       = models.PositiveIntegerField("Макс. использований", default=0, help_text="0 = без ограничений")
    used_count     = models.PositiveIntegerField("Использован раз", default=0, editable=False)

    class Meta:
        verbose_name = "Промокод"
        verbose_name_plural = "Промокоды"
        unique_together = ("branch", "code")

    def __str__(self):
        return f"{self.code} ({self.branch.restaurant.name_ru})"

    def is_valid(self):
        from django.utils import timezone
        if not self.is_active:
            return False, "Промокод неактивен"
        if self.valid_until and self.valid_until < timezone.localdate():
            return False, "Срок действия промокода истёк"
        if self.max_uses > 0 and self.used_count >= self.max_uses:
            return False, "Промокод исчерпан"
        return True, "ok"


class Membership(TimeStampedModel):
    class Role(models.TextChoices):
        OWNER = "owner", "Owner"
        MANAGER = "manager", "Manager"
        CASHIER = "cashier", "Cashier"
        KITCHEN = "kitchen", "Kitchen"

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    restaurant = models.ForeignKey(Restaurant, on_delete=models.CASCADE)
    branch = models.ForeignKey(Branch, on_delete=models.SET_NULL, null=True, blank=True)
    role = models.CharField(max_length=20, choices=Role.choices)
        
    class Meta:
        verbose_name = "Доступ к ресторану"
        verbose_name_plural = "Доступы к ресторанам"
        unique_together = ("user", "restaurant", "branch")

    def __str__(self):
        branch_str = f" / {self.branch.name_ru}" if self.branch else " / все филиалы"
        return f"{self.user} → {self.restaurant}{branch_str} ({self.role})"


class PageView(models.Model):
    SECTION_CHOICES = [
        ("home",       "Главная"),
        ("markets",    "Рынки"),
        ("shops",      "Магазины"),
        ("hotels",     "Отели"),
        ("pharmacy",   "Аптеки"),
        ("legal",      "Юристы"),
        ("eco",        "Эко-проекты"),
        ("restaurant", "Рестораны / меню"),
        ("barbershop", "Барбершопы"),
        ("karaoke",    "Караоке"),
        ("simracing",  "Картинг"),
        ("printshop",  "Полиграфия"),
        ("realty",     "Недвижимость"),
        ("agency",     "Агентства"),
        ("other",      "Другое"),
    ]

    section    = models.CharField("Раздел", max_length=20, choices=SECTION_CHOICES, db_index=True)
    path       = models.CharField("URL", max_length=500)
    ip_hash    = models.CharField("Хэш IP", max_length=64)
    session_key = models.CharField("Сессия", max_length=64, blank=True, default="")
    timestamp  = models.DateTimeField("Время", default=timezone.now, db_index=True)

    class Meta:
        verbose_name        = "Просмотр страницы"
        verbose_name_plural = "Просмотры страниц"
        indexes = [
            models.Index(fields=["section", "timestamp"]),
        ]

    def __str__(self):
        return f"{self.section} {self.path} {self.timestamp:%Y-%m-%d %H:%M}"


class Banner(models.Model):
    """Рекламный баннер на главной странице (три формата)."""

    title        = models.CharField("Название", max_length=200)
    image_wide   = models.ImageField(
        "ПК — широкий (2560×192)",
        upload_to="banners/wide/", blank=True, null=True,
    )
    image_tablet = models.ImageField(
        "Планшет (840×345)",
        upload_to="banners/tablet/", blank=True, null=True,
    )
    image_mobile = models.ImageField(
        "Телефон (850×192)",
        upload_to="banners/mobile/", blank=True, null=True,
    )
    link_url    = models.URLField("Ссылка", blank=True, default="")
    is_active   = models.BooleanField("Активен", default=True)
    sort_order  = models.PositiveSmallIntegerField("Порядок", default=0)
    click_count = models.PositiveIntegerField("Кликов", default=0, editable=False)

    class Meta:
        verbose_name        = "Баннер"
        verbose_name_plural = "Баннеры"
        ordering            = ["sort_order"]

    def __str__(self):
        return self.title


class TeamMember(TimeStampedModel):
    """Команда Webordo — карточка на странице «О нас» (фото, должность, контакты).
    Владелец редактирует всё сам через админку, без правки кода."""

    photo    = models.ImageField("Фото", upload_to="team/", blank=True, null=True)
    name_ru  = models.CharField("Имя (рус)", max_length=150)
    name_ky  = models.CharField("Имя (кырг)", max_length=150, blank=True, default="")
    name_en  = models.CharField("Имя (англ)", max_length=150, blank=True, default="")
    role_ru  = models.CharField("Должность (рус)", max_length=150, default="Директор и CEO")
    role_ky  = models.CharField("Должность (кырг)", max_length=150, blank=True, default="")
    role_en  = models.CharField("Должность (англ)", max_length=150, blank=True, default="")
    bio_ru   = models.TextField("О себе (рус)", blank=True, default="")
    bio_ky   = models.TextField("О себе (кырг)", blank=True, default="")
    bio_en   = models.TextField("О себе (англ)", blank=True, default="")

    phone         = models.CharField("Телефон", max_length=40, blank=True, default="")
    email         = models.EmailField("Email", blank=True, default="")
    whatsapp_url  = models.URLField("WhatsApp (ссылка)", blank=True, default="")
    instagram_url = models.URLField("Instagram", blank=True, default="")

    sort_order = models.PositiveSmallIntegerField("Порядок", default=0)
    is_active  = models.BooleanField("Показывать на сайте", default=True)

    class Meta:
        ordering            = ["sort_order", "id"]
        verbose_name        = "Команда — сотрудник"
        verbose_name_plural = "Команда"

    def __str__(self):
        return f"{self.name_ru} — {self.role_ru}"


class UserProfile(models.Model):
    """Профиль мобильного пользователя — привязан 1:1 к User."""
    user  = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="profile",
    )
    phone = models.CharField("Телефон", max_length=20, unique=True)

    class Meta:
        verbose_name        = "Профиль пользователя"
        verbose_name_plural = "Профили пользователей"

    def __str__(self):
        return f"{self.user.username} ({self.phone})"
